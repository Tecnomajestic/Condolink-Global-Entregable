import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { X, CreditCard, CheckCircle2 } from 'lucide-react';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedUnitId?: string;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({ isOpen, onClose, preselectedUnitId }) => {
  const { units, selectedCondoId, recordPayment, setActiveReceipt, settings, condominiums } = useApp();

  const filteredUnits = selectedCondoId === 'all'
    ? units
    : units.filter(u => u.condoId === selectedCondoId);

  const [unitId, setUnitId] = useState(preselectedUnitId || filteredUnits[0]?.id || '');
  const [amount, setAmount] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<'Transferencia Bancaria' | 'Depósito' | 'Tarjeta de Débito/Crédito' | 'Cheque' | 'Efectivo'>('Transferencia Bancaria');
  const [referenceNumber, setReferenceNumber] = useState('');
  const [destinationAccount, setDestinationAccount] = useState('Cta. Corriente #004-98214-02 (Banco Santander)');
  const [concept, setConcept] = useState('Gasto Común Período Vigente');
  const [notes, setNotes] = useState('');

  const currentUnit = units.find(u => u.id === unitId);

  // Auto-fill amount if unit has debt
  const handleUnitChange = (newUnitId: string) => {
    setUnitId(newUnitId);
    const u = units.find(unit => unit.id === newUnitId);
    if (u && u.currentBalance > 0) {
      setAmount(u.currentBalance.toString());
    }
  };

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUnit || !amount || parseFloat(amount) <= 0) return;

    const receipt = recordPayment({
      condoId: currentUnit.condoId,
      unitId: currentUnit.id,
      unitNumber: currentUnit.unitNumber,
      payerName: currentUnit.primaryResidentName,
      paymentDate: new Date().toISOString().replace('T', ' ').slice(0, 16),
      amount: parseFloat(amount),
      paymentMethod,
      referenceNumber: referenceNumber.trim() || `TX-${Math.floor(1000000 + Math.random() * 9000000)}`,
      destinationAccount,
      concept: concept.trim() || 'Pago de Gasto Común',
      notes,
      verifiedBy: 'Administración Condolink V20.8'
    });

    onClose();
    // Open receipt modal right after!
    setActiveReceipt(receipt);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
          <div className="flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold text-base">Registrar Cobranza / Ingreso</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-sm">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
              Unidad / Copropietario
            </label>
            <select
              value={unitId}
              onChange={(e) => handleUnitChange(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium"
              required
            >
              <option value="">Seleccione una unidad...</option>
              {filteredUnits.map(u => (
                <option key={u.id} value={u.id}>
                  Unidad {u.unitNumber} ({u.towerOrBlock}) - {u.primaryResidentName} · Deuda: {settings.currencySymbol} {u.currentBalance.toFixed(2)}
                </option>
              ))}
            </select>
            {currentUnit && (
              <div className="mt-1.5 flex items-center justify-between text-xs text-slate-500 bg-slate-50 p-2 rounded">
                <span>Estado actual: <strong className={currentUnit.currentBalance > 0 ? 'text-rose-600' : 'text-emerald-600'}>{currentUnit.paymentStatus}</strong></span>
                <span>Saldo adeudado: <strong>{settings.currencySymbol} {currentUnit.currentBalance.toFixed(2)}</strong></span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                Monto a Abonar ({settings.currencyCode})
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-slate-400 font-bold">{settings.currencySymbol}</span>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  required
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full pl-8 pr-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-bold text-base focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                Método de Pago
              </label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as any)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium"
              >
                <option value="Transferencia Bancaria">Transferencia Bancaria</option>
                <option value="Depósito">Depósito en Efectivo/Bancario</option>
                <option value="Tarjeta de Débito/Crédito">Tarjeta Débito/Crédito</option>
                <option value="Cheque">Cheque al Día</option>
                <option value="Efectivo">Efectivo en Portería</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                N° de Operación / Transferencia
              </label>
              <input
                type="text"
                placeholder="Ej. TX-481928"
                value={referenceNumber}
                onChange={(e) => setReferenceNumber(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                Cuenta Bancaria Destino
              </label>
              <input
                type="text"
                value={destinationAccount}
                onChange={(e) => setDestinationAccount(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
              Concepto / Glosa
            </label>
            <input
              type="text"
              value={concept}
              onChange={(e) => setConcept(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
              placeholder="Ej. Gasto Común Noviembre 2026 + Reserva Quincho"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
              Notas u Observaciones (Opcional)
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Detalles adicionales para auditoría..."
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 text-xs"
            />
          </div>

          <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-slate-950 bg-amber-500 hover:bg-amber-600 rounded-lg shadow-xs transition-colors flex items-center gap-1.5"
            >
              <CheckCircle2 className="w-4 h-4" />
              Procesar y Emitir Recibo
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
