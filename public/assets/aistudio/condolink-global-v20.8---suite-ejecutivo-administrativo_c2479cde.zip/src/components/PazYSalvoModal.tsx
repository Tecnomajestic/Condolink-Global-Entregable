import React from 'react';
import { useApp } from '../context/AppContext.tsx';
import { Printer, X, ShieldCheck, Award } from 'lucide-react';

export const PazYSalvoModal: React.FC = () => {
  const { activePazYSalvoUnit, setActivePazYSalvoUnit, condominiums, settings } = useApp();

  if (!activePazYSalvoUnit) return null;

  const condo = condominiums.find(c => c.id === activePazYSalvoUnit.condoId) || condominiums[0];
  const isSolvent = activePazYSalvoUnit.currentBalance <= 0;
  const todayStr = new Date().toLocaleDateString('es-ES', {
    day: '2-digit',
    month: 'long',
    year: 'numeric'
  });

  const certNumber = `PYS-${condo?.code || 'CDL'}-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-xl shadow-2xl overflow-hidden border border-slate-200 my-8">
        {/* Controls */}
        <div className="print:hidden flex items-center justify-between px-6 py-4 bg-slate-900 text-white border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-400" />
            <span className="font-semibold text-sm">Certificado Oficial de Solvencia & Paz y Salvo</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-md bg-amber-500 hover:bg-amber-600 text-slate-950 transition-colors shadow-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              Imprimir Certificado
            </button>
            <button
              onClick={() => setActivePazYSalvoUnit(null)}
              className="p-1.5 rounded-md hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Certificate document */}
        <div className="p-10 text-slate-800 bg-white border-8 border-slate-100">
          <div className="text-center pb-8 border-b-2 border-slate-200">
            <div className="w-14 h-14 mx-auto rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center font-black text-2xl shadow-sm mb-3">
              C
            </div>
            <h1 className="text-xl font-black tracking-wide text-slate-950 uppercase">
              Condolink Global V20.8
            </h1>
            <p className="text-xs uppercase tracking-widest text-slate-500 font-semibold mt-1">
              Administración Central de Copropiedad Inmobiliaria
            </p>
            <p className="text-xs text-slate-600 mt-1">
              {condo?.name} · RUT/ID: {condo?.taxId}
            </p>
          </div>

          <div className="py-8 text-center">
            <h2 className="text-lg font-bold uppercase tracking-wider text-slate-900 underline decoration-amber-500 decoration-2 underline-offset-4">
              Certificado de Paz y Salvo de Gastos Comunes
            </h2>
            <p className="text-xs font-mono text-slate-400 mt-1">Certificado N° {certNumber}</p>
          </div>

          <div className="space-y-4 text-sm leading-relaxed text-slate-700">
            <p>
              Por medio del presente instrumento, la Administración de <strong>{condo?.name}</strong>, debidamente facultada por la Ley de Copropiedad Inmobiliaria y el Reglamento de Copropiedad vigente:
            </p>

            <p className="p-4 bg-slate-50 rounded-lg border border-slate-200 text-slate-800">
              <strong>CERTIFICA QUE:</strong><br />
              La unidad inmobiliaria signada con el <strong>N° {activePazYSalvoUnit.unitNumber}</strong> (Torre/Bloque: {activePazYSalvoUnit.towerOrBlock}, Piso {activePazYSalvoUnit.floor}), alícuota comunitaria de <strong>{activePazYSalvoUnit.aliquotPercentage}%</strong>, de propiedad y/o responsabilidad de <strong>{activePazYSalvoUnit.primaryResidentName}</strong>:
            </p>

            {isSolvent ? (
              <div className="p-4 rounded-lg bg-emerald-50 border border-emerald-300 text-emerald-950 font-medium">
                <div className="flex items-center gap-2 font-bold text-emerald-900 mb-1">
                  <ShieldCheck className="w-5 h-5 text-emerald-600" />
                  SE ENCUENTRA AL DÍA Y SOLVENTE
                </div>
                No registra deudas pendientes por concepto de gastos comunes ordinarios, cuotas extraordinarias, fondo de reserva ni multas a la fecha de emisión del presente certificado. Saldo contable actual: {settings.currencySymbol} 0.00.
              </div>
            ) : (
              <div className="p-4 rounded-lg bg-amber-50 border border-amber-300 text-amber-950 font-medium">
                <div className="flex items-center gap-2 font-bold text-amber-900 mb-1">
                  REGISTRO CON SALDO PENDIENTE
                </div>
                Registra un saldo por regularizar de {settings.currencySymbol} {activePazYSalvoUnit.currentBalance.toLocaleString('es-CL', { minimumFractionDigits: 2 })} correspondiente a {activePazYSalvoUnit.unpaidMonthsCount} período(s).
              </div>
            )}

            <p className="text-xs text-slate-500 pt-2">
              Se extiende el presente certificado a solicitud del interesado para los fines que estime convenientes (escrituras notariales, arriendos, créditos o traspaso de dominio), en {condo?.city}, con fecha <strong>{todayStr}</strong>.
            </p>
          </div>

          <div className="pt-12 flex justify-between items-end border-t border-slate-200 mt-8">
            <div className="text-center w-52">
              <div className="h-12 border-b border-slate-400 mb-2 flex items-center justify-center font-serif italic text-slate-600 text-sm">
                R. Valenzuela C.
              </div>
              <p className="font-bold text-xs text-slate-900">{condo?.administrator}</p>
              <p className="text-[11px] text-slate-500">Administrador Legal Acreditado</p>
            </div>

            <div className="text-center p-3 border border-slate-300 rounded bg-slate-50 text-[10px] text-slate-500 font-mono">
              [TIMBRE ELECTRÓNICO]
              <br />
              CONDOLINK GLOBAL V20.8
              <br />
              HASH: 8F2B-91E0-44A2
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
