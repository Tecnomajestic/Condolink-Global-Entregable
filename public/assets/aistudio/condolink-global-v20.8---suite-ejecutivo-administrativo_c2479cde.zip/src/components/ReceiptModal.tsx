import React from 'react';
import { useApp } from '../context/AppContext.tsx';
import { Printer, X, CheckCircle2, ShieldCheck, Building2 } from 'lucide-react';

export const ReceiptModal: React.FC = () => {
  const { activeReceipt, setActiveReceipt, condominiums, settings } = useApp();

  if (!activeReceipt) return null;

  const condo = condominiums.find(c => c.id === activeReceipt.condoId) || condominiums[0];

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-xl shadow-2xl overflow-hidden border border-slate-200 my-8">
        {/* Modal Controls Bar (hidden during printing) */}
        <div className="print:hidden flex items-center justify-between px-6 py-4 bg-slate-900 text-white border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
            <span className="font-semibold text-sm">Comprobante Oficial de Cobranza V20.8</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-md bg-amber-500 hover:bg-amber-600 text-slate-950 transition-colors shadow-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              Imprimir / PDF
            </button>
            <button
              onClick={() => setActiveReceipt(null)}
              className="p-1.5 rounded-md hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Official Receipt Body */}
        <div className="p-8 text-slate-800 bg-white">
          {/* Header */}
          <div className="flex justify-between items-start pb-6 border-b border-slate-200">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center font-black text-2xl shadow-sm">
                C
              </div>
              <div>
                <h2 className="text-xl font-bold tracking-tight text-slate-900">CONDOLINK GLOBAL</h2>
                <p className="text-xs text-slate-500 font-medium">Suite Ejecutivo Administrativo · Recibo Oficial</p>
                <p className="text-xs text-slate-600 mt-0.5">{condo?.name}</p>
                <p className="text-xs text-slate-500">RUT / ID Tributario: {condo?.taxId}</p>
              </div>
            </div>
            <div className="text-right">
              <div className="inline-block px-3 py-1 bg-emerald-50 border border-emerald-200 rounded text-emerald-800 text-xs font-bold uppercase tracking-wider">
                Cobro Verificado
              </div>
              <p className="text-sm font-bold text-slate-900 mt-2">{activeReceipt.receiptNumber}</p>
              <p className="text-xs text-slate-500">Fecha: {activeReceipt.paymentDate}</p>
            </div>
          </div>

          {/* Details Grid */}
          <div className="grid grid-cols-2 gap-4 py-6 border-b border-slate-200 text-sm">
            <div>
              <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-1">Unidad Inmobiliaria</p>
              <p className="font-bold text-slate-900 text-base">Unidad {activeReceipt.unitNumber}</p>
              <p className="text-xs text-slate-600 mt-0.5">{condo?.address}, {condo?.city}</p>
            </div>
            <div>
              <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-1">Copropietario / Pagador</p>
              <p className="font-bold text-slate-900 text-base">{activeReceipt.payerName}</p>
              <p className="text-xs text-slate-600 mt-0.5">Método: {activeReceipt.paymentMethod}</p>
            </div>
          </div>

          {/* Concept Table */}
          <div className="py-6 border-b border-slate-200">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-xs font-semibold uppercase tracking-wider text-slate-500">
                  <th className="pb-2">Descripción / Concepto</th>
                  <th className="pb-2 text-right">Referencia</th>
                  <th className="pb-2 text-right">Total Aplicado</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                <tr>
                  <td className="py-3 font-medium text-slate-800">
                    {activeReceipt.concept}
                  </td>
                  <td className="py-3 text-right text-xs font-mono text-slate-500">
                    {activeReceipt.referenceNumber}
                  </td>
                  <td className="py-3 text-right font-bold text-slate-900">
                    {settings.currencySymbol} {activeReceipt.amount.toLocaleString('es-CL', { minimumFractionDigits: 2 })}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Total & Banking */}
          <div className="flex justify-between items-center py-6 border-b border-slate-200">
            <div className="text-xs text-slate-500 space-y-1">
              <p><span className="font-medium text-slate-700">Depósito Destino:</span> {activeReceipt.destinationAccount}</p>
              <p><span className="font-medium text-slate-700">Auditoría / Verificado por:</span> {activeReceipt.verifiedBy}</p>
            </div>
            <div className="text-right">
              <span className="text-xs uppercase tracking-wider text-slate-500 font-semibold block">Total Percibido</span>
              <span className="text-2xl font-black text-emerald-600">
                {settings.currencySymbol} {activeReceipt.amount.toLocaleString('es-CL', { minimumFractionDigits: 2 })}
              </span>
              <span className="text-xs text-slate-400 block font-mono">{condo?.currency || 'USD'}</span>
            </div>
          </div>

          {/* Security & Stamp */}
          <div className="pt-6 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-16 h-16 p-1 border border-slate-300 rounded bg-slate-50 flex items-center justify-center text-[9px] font-mono text-center text-slate-500">
                [QR OFICIAL CONDOLINK]
              </div>
              <div className="text-xs text-slate-500">
                <p className="font-medium text-slate-800 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  Validez Tributaria & Condominal Certificada
                </p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Firma Electrónica V20.8 registrada en libro mayor contable descentralizado.
                </p>
              </div>
            </div>
            <div className="text-center text-xs text-slate-500 border-t border-slate-300 pt-2 px-6">
              <p className="font-semibold text-slate-800">{condo?.administrator}</p>
              <p className="text-[11px] text-slate-400">Administración General Condolink</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
