import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { X, Building, CheckCircle2 } from 'lucide-react';
import { Unit, UnitType, OccupancyStatus } from '../types/index.ts';

interface UnitModalProps {
  isOpen: boolean;
  onClose: () => void;
  unitToEdit?: Unit | null;
}

export const UnitModal: React.FC<UnitModalProps> = ({ isOpen, onClose, unitToEdit }) => {
  const { selectedCondoId, condominiums, addUnit, updateUnit } = useApp();

  const [condoId, setCondoId] = useState(unitToEdit ? unitToEdit.condoId : (selectedCondoId === 'all' ? condominiums[0]?.id : selectedCondoId));
  const [unitNumber, setUnitNumber] = useState('');
  const [towerOrBlock, setTowerOrBlock] = useState('Torre A');
  const [floor, setFloor] = useState(1);
  const [type, setType] = useState<UnitType>('Apartamento');
  const [areaSqMeters, setAreaSqMeters] = useState(80);
  const [aliquotPercentage, setAliquotPercentage] = useState(2.0);
  const [parkingSpots, setParkingSpots] = useState('');
  const [storageUnit, setStorageUnit] = useState('');
  const [occupancyStatus, setOccupancyStatus] = useState<OccupancyStatus>('Propietario Residente');
  const [primaryResidentName, setPrimaryResidentName] = useState('');
  const [primaryResidentEmail, setPrimaryResidentEmail] = useState('');
  const [primaryResidentPhone, setPrimaryResidentPhone] = useState('');

  useEffect(() => {
    if (unitToEdit) {
      setCondoId(unitToEdit.condoId);
      setUnitNumber(unitToEdit.unitNumber);
      setTowerOrBlock(unitToEdit.towerOrBlock);
      setFloor(unitToEdit.floor);
      setType(unitToEdit.type);
      setAreaSqMeters(unitToEdit.areaSqMeters);
      setAliquotPercentage(unitToEdit.aliquotPercentage);
      setParkingSpots(unitToEdit.parkingSpots);
      setStorageUnit(unitToEdit.storageUnit);
      setOccupancyStatus(unitToEdit.occupancyStatus);
      setPrimaryResidentName(unitToEdit.primaryResidentName);
      setPrimaryResidentEmail(unitToEdit.primaryResidentEmail);
      setPrimaryResidentPhone(unitToEdit.primaryResidentPhone);
    } else {
      setUnitNumber('');
      setTowerOrBlock('Torre A');
      setFloor(1);
      setType('Apartamento');
      setAreaSqMeters(85);
      setAliquotPercentage(2.1);
      setParkingSpots('');
      setStorageUnit('');
      setOccupancyStatus('Propietario Residente');
      setPrimaryResidentName('');
      setPrimaryResidentEmail('');
      setPrimaryResidentPhone('');
    }
  }, [unitToEdit, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!unitNumber || !primaryResidentName) return;

    if (unitToEdit) {
      updateUnit({
        ...unitToEdit,
        condoId,
        unitNumber,
        towerOrBlock,
        floor: Number(floor),
        type,
        areaSqMeters: Number(areaSqMeters),
        aliquotPercentage: Number(aliquotPercentage),
        parkingSpots,
        storageUnit,
        occupancyStatus,
        primaryResidentName,
        primaryResidentEmail,
        primaryResidentPhone
      });
    } else {
      addUnit({
        condoId: condoId || condominiums[0]?.id,
        unitNumber,
        towerOrBlock,
        floor: Number(floor),
        type,
        areaSqMeters: Number(areaSqMeters),
        aliquotPercentage: Number(aliquotPercentage),
        parkingSpots,
        storageUnit,
        occupancyStatus,
        primaryResidentName,
        primaryResidentEmail,
        primaryResidentPhone
      });
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="relative w-full max-w-xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden my-6">
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
          <div className="flex items-center gap-2">
            <Building className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold text-base">
              {unitToEdit ? `Editar Unidad ${unitToEdit.unitNumber}` : 'Registrar Nueva Unidad Inmobiliaria'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-sm max-h-[80vh] overflow-y-auto">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
              Condominio / Inmueble
            </label>
            <select
              value={condoId}
              onChange={(e) => setCondoId(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium"
              required
            >
              {condominiums.map(c => (
                <option key={c.id} value={c.id}>{c.name} ({c.code})</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                N° de Unidad / Depto
              </label>
              <input
                type="text"
                required
                placeholder="Ej. 402, PH-02"
                value={unitNumber}
                onChange={(e) => setUnitNumber(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                Torre o Bloque
              </label>
              <input
                type="text"
                placeholder="Ej. Torre A, Bloque 2"
                value={towerOrBlock}
                onChange={(e) => setTowerOrBlock(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                Piso
              </label>
              <input
                type="number"
                value={floor}
                onChange={(e) => setFloor(Number(e.target.value))}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                Tipo
              </label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as any)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 text-xs"
              >
                <option value="Apartamento">Apartamento</option>
                <option value="Penthouse">Penthouse</option>
                <option value="Casa">Casa</option>
                <option value="Oficina">Oficina</option>
                <option value="Local Comercial">Local Comercial</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                Superficie (m²)
              </label>
              <input
                type="number"
                step="0.1"
                value={areaSqMeters}
                onChange={(e) => setAreaSqMeters(Number(e.target.value))}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                Alícuota Legal (%)
              </label>
              <input
                type="number"
                step="0.01"
                value={aliquotPercentage}
                onChange={(e) => setAliquotPercentage(Number(e.target.value))}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono font-semibold focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                Estacionamiento(s)
              </label>
              <input
                type="text"
                placeholder="Ej. E-14, E-15"
                value={parkingSpots}
                onChange={(e) => setParkingSpots(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                Bodega / Baulera
              </label>
              <input
                type="text"
                placeholder="Ej. B-08 Subterráneo -1"
                value={storageUnit}
                onChange={(e) => setStorageUnit(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          <div className="border-t border-slate-200 pt-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
              Datos del Propietario / Residente Principal
            </h4>
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                  Nombre Completo
                </label>
                <input
                  type="text"
                  required
                  placeholder="Nombre y Apellidos"
                  value={primaryResidentName}
                  onChange={(e) => setPrimaryResidentName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Correo Electrónico
                  </label>
                  <input
                    type="email"
                    placeholder="propietario@email.com"
                    value={primaryResidentEmail}
                    onChange={(e) => setPrimaryResidentEmail(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Teléfono de Contacto
                  </label>
                  <input
                    type="text"
                    placeholder="+56 9 8888 7777"
                    value={primaryResidentPhone}
                    onChange={(e) => setPrimaryResidentPhone(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                  Condición de Ocupación
                </label>
                <select
                  value={occupancyStatus}
                  onChange={(e) => setOccupancyStatus(e.target.value as any)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs font-medium"
                >
                  <option value="Propietario Residente">Propietario Residente</option>
                  <option value="Arrendado">Arrendado (Con Inquilino)</option>
                  <option value="Desocupado">Desocupado / En Venta</option>
                  <option value="En Remodelación">En Remodelación / Trabajos</option>
                </select>
              </div>
            </div>
          </div>

          <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-slate-950 bg-amber-500 hover:bg-amber-600 rounded-lg shadow-xs transition-colors flex items-center gap-1.5"
            >
              <CheckCircle2 className="w-4 h-4" />
              {unitToEdit ? 'Guardar Cambios' : 'Registrar Unidad'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
