import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { X, Calendar, DollarSign, Calculator, CheckCircle2 } from 'lucide-react';

interface InvoiceGenerationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InvoiceGenerationModal: React.FC<InvoiceGenerationModalProps> = ({ isOpen, onClose }) => {
  const { selectedCondoId, condominiums, units, generateMonthlyInvoices, settings } = useApp();

  const [period, setPeriod] = useState('Diciembre 2026');
  const [dueDate, setDueDate] = useState('2026-12-15');
  const [baseMultiplier, setBaseMultiplier] = useState(2.2);
  const [resultMessage, setResultMessage] = useState<{ count: number; total: number } | null>(null);

  const condo = condominiums.find(c => c.id === selectedCondoId);
  const affectedUnits = selectedCondoId === 'all'
    ? units
    : units.filter(u => u.condoId === selectedCondoId);

  if (!isOpen) return null;

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    const res = generateMonthlyInvoices(period, dueDate, Number(baseMultiplier));
    setResultMessage(res);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
          <div className="flex items-center gap-2">
            <Calculator className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold text-base">Emisión Masiva de Gastos Comunes</h3>
          </div>
          <button
            onClick={() => {
              setResultMessage(null);
              onClose();
            }}
            className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {resultMessage ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h3 className="text-xl font-bold text-slate-900">¡Emisión Generada con Éxito!</h3>
            <p className="text-sm text-slate-600 max-w-sm mx-auto">
              Se han emitido <strong>{resultMessage.count} cobros oficiales</strong> para el período <strong>{period}</strong> por un monto total facturado de:
            </p>
            <div className="text-3xl font-black text-emerald-600 font-mono">
              {settings.currencySymbol} {resultMessage.total.toLocaleString('es-CL', { minimumFractionDigits: 2 })}
            </div>
            <p className="text-xs text-slate-400">
              Las cuentas por cobrar de cada unidad han sido actualizadas y las boletas digitales ya están disponibles para los copropietarios.
            </p>
            <div className="pt-4">
              <button
                onClick={() => {
                  setResultMessage(null);
                  onClose();
                }}
                className="px-6 py-2.5 bg-slate-900 text-white font-bold text-xs rounded-lg hover:bg-slate-800 transition-colors"
              >
                Cerrar y Ver Cobranzas
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleGenerate} className="p-6 space-y-4 text-sm">
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-xs text-amber-900 flex items-start gap-2">
              <span className="font-bold text-amber-700">Aviso:</span>
              <span>
                Esta acción calculará automáticamente la alícuota de cada unidad, agregará el 5% de fondo de reserva legal y generará la factura oficial para {affectedUnits.length} departamentos ({selectedCondoId === 'all' ? 'todos los condominios' : condo?.name}).
              </span>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                  Período a Facturar
                </label>
                <input
                  type="text"
                  required
                  value={period}
                  onChange={(e) => setPeriod(e.target.value)}
                  placeholder="Ej. Diciembre 2026"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                  Fecha de Vencimiento
                </label>
                <input
                  type="date"
                  required
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                Factor Base Cuota por m² ({settings.currencySymbol} / m²)
              </label>
              <input
                type="number"
                step="0.1"
                min="0.5"
                required
                value={baseMultiplier}
                onChange={(e) => setBaseMultiplier(Number(e.target.value))}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">
                Multiplicador base por metro cuadrado útil. Para una unidad de 85 m², la cuota base será de ~{settings.currencySymbol} {(85 * baseMultiplier).toFixed(2)}.
              </span>
            </div>

            <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-200">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-5 py-2 text-xs font-bold text-slate-950 bg-amber-500 hover:bg-amber-600 rounded-lg shadow-xs transition-colors flex items-center gap-1.5"
              >
                <Calculator className="w-4 h-4" />
                Ejecutar Emisión Masiva
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
