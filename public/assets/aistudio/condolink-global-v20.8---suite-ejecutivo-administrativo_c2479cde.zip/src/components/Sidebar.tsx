import React from 'react';
import {
  LayoutDashboard,
  Building2,
  Home,
  DollarSign,
  Wrench,
  CalendarDays,
  ShieldCheck,
  Vote,
  BellRing,
  UserCheck,
  FileText
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';

export type NavView =
  | 'dashboard'
  | 'condos'
  | 'units'
  | 'finance'
  | 'maintenance'
  | 'amenities'
  | 'concierge'
  | 'assemblies'
  | 'notices'
  | 'resident';

interface SidebarProps {
  currentView: NavView;
  onSelectView: (view: NavView) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, onSelectView }) => {
  const { currentRole, tickets, packages, invoices } = useApp();

  const pendingTickets = tickets.filter(t => t.status === 'Reportado' || t.status === 'En Proceso').length;
  const packagesInDesk = packages.filter(p => p.status === 'En Conserjería').length;
  const overdueInvoices = invoices.filter(i => i.status === 'Vencido').length;

  const navGroups = [
    {
      title: 'VISIÓN GENERAL',
      items: [
        { id: 'dashboard' as NavView, label: 'Panel Ejecutivo', icon: LayoutDashboard }
      ]
    },
    {
      title: 'INMOBILIARIA & PROPIEDAD',
      items: [
        { id: 'condos' as NavView, label: 'Condominios & Torres', icon: Building2 },
        { id: 'units' as NavView, label: 'Unidades & Copropietarios', icon: Home }
      ]
    },
    {
      title: 'SUITE CONTABLE Y FINANZAS',
      items: [
        {
          id: 'finance' as NavView,
          label: 'Contabilidad & Cobranzas',
          icon: DollarSign,
          badge: overdueInvoices > 0 ? `${overdueInvoices} mora` : undefined
        }
      ]
    },
    {
      title: 'OPERACIONES & CONTROL',
      items: [
        {
          id: 'maintenance' as NavView,
          label: 'Mantenimiento & Incidencias',
          icon: Wrench,
          badge: pendingTickets > 0 ? String(pendingTickets) : undefined
        },
        { id: 'amenities' as NavView, label: 'Amenidades & Reservas', icon: CalendarDays },
        {
          id: 'concierge' as NavView,
          label: 'Conserjería & Encomiendas',
          icon: ShieldCheck,
          badge: packagesInDesk > 0 ? `${packagesInDesk} pqts` : undefined
        }
      ]
    },
    {
      title: 'GOBERNANZA COMUNITARIA',
      items: [
        { id: 'assemblies' as NavView, label: 'Asambleas & Votaciones', icon: Vote },
        { id: 'notices' as NavView, label: 'Circulares & Avisos', icon: BellRing }
      ]
    },
    {
      title: 'AUTOSERVICIO',
      items: [
        { id: 'resident' as NavView, label: 'Portal Copropietario', icon: UserCheck }
      ]
    }
  ];

  return (
    <aside className="w-64 bg-slate-950 border-r border-slate-800 text-slate-300 flex flex-col shrink-0 min-h-[calc(100vh-4rem)]">
      <div className="p-4 space-y-6 flex-1 overflow-y-auto">
        {navGroups.map((group, gIdx) => (
          <div key={gIdx} className="space-y-1">
            <h3 className="px-3 text-[11px] font-bold uppercase tracking-wider text-slate-500">
              {group.title}
            </h3>
            <div className="mt-1 space-y-0.5">
              {group.items.map((item) => {
                const Icon = item.icon;
                const active = currentView === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onSelectView(item.id)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                      active
                        ? 'bg-amber-500/10 text-amber-400 font-semibold border-l-2 border-amber-400 pl-2.5'
                        : 'hover:bg-slate-900 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-amber-400' : 'text-slate-500'}`} />
                      <span className="truncate">{item.label}</span>
                    </div>
                    {item.badge && (
                      <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-amber-400 border border-slate-700">
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Footer info */}
      <div className="p-4 border-t border-slate-900 bg-slate-950/80 text-[11px] text-slate-500 flex items-center justify-between">
        <div>
          <p className="font-semibold text-slate-400">Condolink Global</p>
          <p className="text-[10px] text-slate-600">Edición V20.8 Enterprise</p>
        </div>
        <div className="w-2 h-2 rounded-full bg-emerald-500" title="Sistema Operativo"></div>
      </div>
    </aside>
  );
};
