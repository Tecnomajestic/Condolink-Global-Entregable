import React from 'react';
import { useApp, UserRole } from '../context/AppContext.tsx';
import { Building2, Plus, CreditCard, Receipt, Settings, UserCheck, ShieldAlert, Sparkles } from 'lucide-react';

interface HeaderProps {
  onOpenPaymentModal: () => void;
  onOpenExpenseModal: () => void;
  onOpenSettingsModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenPaymentModal,
  onOpenExpenseModal,
  onOpenSettingsModal
}) => {
  const {
    condominiums,
    selectedCondoId,
    setSelectedCondoId,
    currentRole,
    setCurrentRole,
    settings
  } = useApp();

  const roleLabels: Record<UserRole, { label: string; desc: string }> = {
    ADMIN_EJECUTIVO: { label: 'Admin Ejecutivo', desc: 'Control Total V20.8' },
    CONTADOR: { label: 'Contador / Finanzas', desc: 'Libros y Balances' },
    CONSERJERIA: { label: 'Conserjería / Portería', desc: 'Accesos y Paquetes' },
    RESIDENTE: { label: 'Portal Residente', desc: 'Autoservicio Copropietario' }
  };

  return (
    <header className="sticky top-0 z-30 bg-slate-900 border-b border-slate-800 text-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand & Condominium selector */}
        <div className="flex items-center gap-4 min-w-0">
          <div className="flex items-center gap-2.5 shrink-0">
            {/* Matching yellow icon with letter 'C' from screenshot */}
            <div className="w-9 h-9 rounded-lg bg-amber-400 text-slate-950 flex items-center justify-center font-black text-xl shadow-sm tracking-tighter">
              C
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-base tracking-tight text-white">CONDOLINK GLOBAL</span>
                <span className="px-1.5 py-0.5 text-[10px] font-mono font-bold bg-amber-400/20 text-amber-300 rounded border border-amber-400/30">
                  V20.8
                </span>
              </div>
              <p className="text-[11px] text-slate-400 truncate max-w-xs hidden sm:block">
                Suite Ejecutivo Administrativo
              </p>
            </div>
          </div>

          <div className="h-6 w-px bg-slate-800 hidden md:block"></div>

          {/* Condominium switcher */}
          <div className="relative flex items-center gap-1.5 bg-slate-800/80 px-2.5 py-1.5 rounded-lg border border-slate-700/80 text-xs">
            <Building2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <select
              value={selectedCondoId}
              onChange={(e) => setSelectedCondoId(e.target.value)}
              className="bg-transparent text-white font-medium focus:outline-none cursor-pointer pr-4 text-xs"
            >
              <option value="all" className="bg-slate-900 text-white">
                🌐 Todos los Condominios ({condominiums.length})
              </option>
              {condominiums.map(c => (
                <option key={c.id} value={c.id} className="bg-slate-900 text-white">
                  🏢 {c.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Right side controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Quick role selector */}
          <div className="hidden lg:flex items-center bg-slate-800/60 p-1 rounded-lg border border-slate-800 text-xs">
            {(Object.keys(roleLabels) as UserRole[]).map((r) => {
              const active = currentRole === r;
              return (
                <button
                  key={r}
                  onClick={() => setCurrentRole(r)}
                  className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                    active
                      ? 'bg-amber-500 text-slate-950 font-bold shadow-xs'
                      : 'text-slate-400 hover:text-white'
                  }`}
                  title={roleLabels[r].desc}
                >
                  {roleLabels[r].label}
                </button>
              );
            })}
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={onOpenPaymentModal}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white transition-colors shadow-xs"
              title="Registrar pago recibido"
            >
              <CreditCard className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Cobranza</span>
            </button>

            <button
              onClick={onOpenExpenseModal}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
              title="Registrar factura o egreso"
            >
              <Receipt className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">Egreso</span>
            </button>

            <button
              onClick={onOpenSettingsModal}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white border border-slate-700 transition-colors"
              title="Configuración y Respaldo"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
