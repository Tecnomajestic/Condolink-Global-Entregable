import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { X, Receipt, PlusCircle } from 'lucide-react';
import { ExpenseRecord } from '../types/index.ts';

interface ExpenseModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExpenseModal: React.FC<ExpenseModalProps> = ({ isOpen, onClose }) => {
  const { selectedCondoId, condominiums, recordExpense, settings } = useApp();

  const [condoId, setCondoId] = useState(selectedCondoId === 'all' ? condominiums[0]?.id : selectedCondoId);
  const [category, setCategory] = useState<ExpenseRecord['category']>('Servicios Básicos (Luz/Agua)');
  const [supplier, setSupplier] = useState('');
  const [supplierTaxId, setSupplierTaxId] = useState('');
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [description, setDescription] = useState('');
  const [dueDate, setDueDate] = useState(new Date().toISOString().split('T')[0]);
  const [amount, setAmount] = useState('');
  const [status, setStatus] = useState<ExpenseRecord['status']>('Pendiente');
  const [paymentMethod, setPaymentMethod] = useState('Transferencia Bancaria');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supplier || !amount || parseFloat(amount) <= 0) return;

    recordExpense({
      condoId: condoId || condominiums[0]?.id,
      category,
      supplier,
      supplierTaxId: supplierTaxId || 'CL-96.100.000-1',
      invoiceNumber: invoiceNumber || `FAC-${Math.floor(10000 + Math.random() * 90000)}`,
      description,
      issueDate: new Date().toISOString().split('T')[0],
      dueDate,
      amount: parseFloat(amount),
      status,
      paymentMethod: status === 'Pagado' ? paymentMethod : undefined,
      paymentDate: status === 'Pagado' ? new Date().toISOString().split('T')[0] : undefined
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
          <div className="flex items-center gap-2">
            <Receipt className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold text-base">Registrar Cuenta por Pagar / Egreso</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-sm">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
              Condominio / Inmueble Afecto
            </label>
            <select
              value={condoId}
              onChange={(e) => setCondoId(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium"
              required
            >
              {condominiums.map(c => (
                <option key={c.id} value={c.id}>{c.name} ({c.code})</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                Categoría Contable
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 text-xs"
              >
                <option value="Servicios Básicos (Luz/Agua)">Servicios Básicos (Luz/Agua)</option>
                <option value="Mantenimiento y Reparaciones">Mantenimiento y Reparaciones</option>
                <option value="Seguridad y Vigilancia">Seguridad y Vigilancia</option>
                <option value="Limpieza y Desinfección">Limpieza y Desinfección</option>
                <option value="Honorarios Administración">Honorarios Administración</option>
                <option value="Seguros">Pólizas de Seguros</option>
                <option value="Otros">Otros Gastos Operacionales</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                Monto del Egreso ({settings.currencyCode})
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-slate-400 font-bold">{settings.currencySymbol}</span>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  required
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full pl-8 pr-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-bold text-base focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                Proveedor / Empresa
              </label>
              <input
                type="text"
                required
                placeholder="Ej. Enel, Schindler, Securitas..."
                value={supplier}
                onChange={(e) => setSupplier(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                RUT / NIF Proveedor
              </label>
              <input
                type="text"
                placeholder="Ej. 76.123.456-7"
                value={supplierTaxId}
                onChange={(e) => setSupplierTaxId(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                N° de Factura / Boleta
              </label>
              <input
                type="text"
                placeholder="Ej. FAC-10492"
                value={invoiceNumber}
                onChange={(e) => setInvoiceNumber(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                Fecha de Vencimiento
              </label>
              <input
                type="date"
                required
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
              Descripción del Bien o Servicio
            </label>
            <input
              type="text"
              required
              placeholder="Ej. Suministro eléctrico común correspondiente a octubre..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-4 bg-slate-50 p-3 rounded-lg border border-slate-200">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                Estado Inicial
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as any)}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md text-slate-900 text-xs font-medium"
              >
                <option value="Pendiente">Pendiente de Pago</option>
                <option value="Pagado">Pagado Inmediato</option>
                <option value="En Aprobación">En Aprobación de Comité</option>
              </select>
            </div>

            {status === 'Pagado' && (
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                  Medio de Pago
                </label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md text-slate-900 text-xs font-medium"
                >
                  <option value="Transferencia Bancaria">Transferencia Bancaria</option>
                  <option value="Cheque Empresa">Cheque Empresa</option>
                  <option value="Cargo Automático">Cargo Automático PAC</option>
                </select>
              </div>
            )}
          </div>

          <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-slate-950 bg-amber-500 hover:bg-amber-600 rounded-lg shadow-xs transition-colors flex items-center gap-1.5"
            >
              <PlusCircle className="w-4 h-4" />
              Guardar Egreso
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
