import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import {
  BellRing,
  Plus,
  Pin,
  Calendar,
  AlertTriangle,
  FileText,
  Trash2,
  X
} from 'lucide-react';
import { OfficialNotice } from '../types/index.ts';

export const NoticesView: React.FC = () => {
  const {
    notices,
    selectedCondoId,
    condominiums,
    createNotice,
    deleteNotice
  } = useApp();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [condoId, setCondoId] = useState(selectedCondoId === 'all' ? condominiums[0]?.id : selectedCondoId);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<OfficialNotice['category']>('Informativo');
  const [author, setAuthor] = useState('Comité de Administración & Condolink Global');
  const [content, setContent] = useState('');
  const [pinned, setPinned] = useState(false);

  const filteredNotices = notices.filter(n => {
    if (selectedCondoId !== 'all' && n.condoId !== selectedCondoId) return false;
    return true;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !content) return;

    createNotice({
      condoId: condoId || condominiums[0]?.id,
      title,
      category,
      author,
      content,
      pinned
    });

    setIsModalOpen(false);
    setTitle('');
    setContent('');
    setPinned(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">
            Circulares Oficiales & Comunicados a la Comunidad
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Publicación formal de boletines, avisos de corte, mantenimientos y normativas de convivencia.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 transition-colors shadow-xs shrink-0"
        >
          <Plus className="w-4 h-4" />
          Publicar Circular Oficial
        </button>
      </div>

      {/* Notices List */}
      <div className="space-y-4">
        {filteredNotices.map((notice) => (
          <div
            key={notice.id}
            className={`bg-white rounded-xl border p-5 shadow-xs transition-all ${
              notice.pinned
                ? 'border-amber-300 ring-1 ring-amber-200'
                : 'border-slate-200'
            }`}
          >
            <div className="flex items-start justify-between gap-3 mb-2">
              <div className="flex items-center gap-2">
                {notice.pinned && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800">
                    <Pin className="w-3 h-3 text-amber-700" /> Fijado
                  </span>
                )}
                <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                  {notice.category}
                </span>
                <span className="text-slate-400 text-xs">·</span>
                <span className="text-xs text-slate-400 font-medium">{notice.date}</span>
              </div>

              <button
                onClick={() => deleteNotice(notice.id)}
                className="p-1 rounded text-slate-400 hover:text-rose-600 transition-colors"
                title="Eliminar circular"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>

            <h3 className="font-bold text-slate-900 text-base mb-2">{notice.title}</h3>
            <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-line">{notice.content}</p>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
              <span>Emitido por: <strong className="text-slate-600">{notice.author}</strong></span>
              <span className="text-emerald-600 font-semibold">Notificación Distribuida</span>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="relative w-full max-w-lg bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden my-6">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
              <div className="flex items-center gap-2">
                <BellRing className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-base">Publicar Circular Oficial</h3>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-sm">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                  Inmueble / Condominio
                </label>
                <select
                  value={condoId}
                  onChange={(e) => setCondoId(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-medium"
                >
                  {condominiums.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                  Título del Comunicado
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ej. Mantención general de ductos de basura"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Categoría
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs"
                  >
                    <option value="Informativo">Informativo</option>
                    <option value="Urgente">Urgente</option>
                    <option value="Mantenimiento">Mantenimiento</option>
                    <option value="Financiero">Financiero</option>
                    <option value="Convivencia">Convivencia</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Emisor / Firma
                  </label>
                  <input
                    type="text"
                    value={author}
                    onChange={(e) => setAuthor(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                  Cuerpo del Comunicado
                </label>
                <textarea
                  rows={4}
                  required
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Escriba aquí los detalles del anuncio para toda la comunidad..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs"
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="pinNotice"
                  checked={pinned}
                  onChange={(e) => setPinned(e.target.checked)}
                  className="w-4 h-4 rounded text-amber-500 focus:ring-amber-400"
                />
                <label htmlFor="pinNotice" className="text-xs font-semibold text-slate-700">
                  Fijar este comunicado en la parte superior del portal
                </label>
              </div>

              <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-slate-950 bg-amber-500 hover:bg-amber-600 rounded-lg shadow-xs transition-colors"
                >
                  Publicar Comunicado
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
