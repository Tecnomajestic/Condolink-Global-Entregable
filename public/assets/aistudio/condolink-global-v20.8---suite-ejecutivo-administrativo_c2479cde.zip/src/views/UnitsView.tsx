import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import {
  Building2,
  Search,
  Filter,
  Plus,
  FileCheck,
  CreditCard,
  Edit2,
  Trash2,
  Phone,
  Mail,
  Car,
  ShieldCheck,
  AlertTriangle
} from 'lucide-react';
import { Unit } from '../types/index.ts';

interface UnitsViewProps {
  onOpenUnitModal: (unit?: Unit | null) => void;
  onOpenPaymentModalWithUnit: (unitId: string) => void;
}

export const UnitsView: React.FC<UnitsViewProps> = ({
  onOpenUnitModal,
  onOpenPaymentModalWithUnit
}) => {
  const {
    units,
    condominiums,
    selectedCondoId,
    deleteUnit,
    settings,
    setActivePazYSalvoUnit
  } = useApp();

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'Solvente' | 'En Mora'>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');

  const filtered = units.filter(u => {
    if (selectedCondoId !== 'all' && u.condoId !== selectedCondoId) return false;
    if (statusFilter !== 'all' && u.paymentStatus !== statusFilter) return false;
    if (typeFilter !== 'all' && u.type !== typeFilter) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      const matchNum = u.unitNumber.toLowerCase().includes(q);
      const matchName = u.primaryResidentName.toLowerCase().includes(q);
      const matchTower = u.towerOrBlock.toLowerCase().includes(q);
      return matchNum || matchName || matchTower;
    }
    return true;
  });

  const totalAliquot = filtered.reduce((acc, u) => acc + u.aliquotPercentage, 0);

  return (
    <div className="space-y-5">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">
            Directorio de Unidades & Copropietarios
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Inventario inmobiliario, alícuotas condominales, estados de solvencia y emisión de Paz y Salvo.
          </p>
        </div>

        <button
          onClick={() => onOpenUnitModal(null)}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 transition-colors shadow-xs shrink-0"
        >
          <Plus className="w-4 h-4" />
          Registrar Nueva Unidad
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Buscar por N° unidad, copropietario o torre..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          {/* Status filter tabs */}
          <div className="flex items-center p-1 bg-slate-100 rounded-lg text-xs font-medium">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-3 py-1 rounded-md transition-colors ${statusFilter === 'all' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'}`}
            >
              Todos ({units.length})
            </button>
            <button
              onClick={() => setStatusFilter('Solvente')}
              className={`px-3 py-1 rounded-md transition-colors ${statusFilter === 'Solvente' ? 'bg-white text-emerald-700 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'}`}
            >
              Solventes
            </button>
            <button
              onClick={() => setStatusFilter('En Mora')}
              className={`px-3 py-1 rounded-md transition-colors ${statusFilter === 'En Mora' ? 'bg-white text-rose-700 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'}`}
            >
              En Mora
            </button>
          </div>

          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="px-3 py-2 border border-slate-200 rounded-lg text-xs bg-white text-slate-700 focus:outline-none"
          >
            <option value="all">Todos los tipos</option>
            <option value="Apartamento">Apartamento</option>
            <option value="Penthouse">Penthouse</option>
            <option value="Casa">Casa</option>
            <option value="Local Comercial">Local Comercial</option>
          </select>
        </div>
      </div>

      {/* Units Table / Grid */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase tracking-wider font-semibold text-[11px]">
                <th className="py-3 px-4">Unidad / Ubicación</th>
                <th className="py-3 px-4">Copropietario & Contacto</th>
                <th className="py-3 px-4">Alícuota & Sup.</th>
                <th className="py-3 px-4">Estacionamiento / Bodega</th>
                <th className="py-3 px-4">Ocupación</th>
                <th className="py-3 px-4 text-right">Saldo Deudor</th>
                <th className="py-3 px-4 text-center">Acciones Ejecutivas</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((unit) => {
                const condo = condominiums.find(c => c.id === unit.condoId);
                const isDelinquent = unit.currentBalance > 0;

                return (
                  <tr key={unit.id} className="hover:bg-slate-50/70 transition-colors">
                    {/* Unit & Building */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-lg bg-slate-900 text-amber-400 font-bold flex items-center justify-center text-xs shrink-0">
                          {unit.unitNumber}
                        </div>
                        <div>
                          <p className="font-bold text-slate-900 text-sm">Depto {unit.unitNumber}</p>
                          <p className="text-[11px] text-slate-500">{unit.towerOrBlock} · Piso {unit.floor}</p>
                          {selectedCondoId === 'all' && (
                            <p className="text-[10px] text-amber-700 font-medium truncate max-w-[150px]">{condo?.name}</p>
                          )}
                        </div>
                      </div>
                    </td>

                    {/* Resident */}
                    <td className="py-3 px-4">
                      <p className="font-semibold text-slate-900">{unit.primaryResidentName}</p>
                      <div className="flex items-center gap-3 text-[11px] text-slate-500 mt-0.5">
                        {unit.primaryResidentPhone && (
                          <span className="flex items-center gap-1">
                            <Phone className="w-3 h-3 text-slate-400" />
                            {unit.primaryResidentPhone}
                          </span>
                        )}
                        {unit.primaryResidentEmail && (
                          <span className="flex items-center gap-1">
                            <Mail className="w-3 h-3 text-slate-400" />
                            {unit.primaryResidentEmail}
                          </span>
                        )}
                      </div>
                    </td>

                    {/* Aliquot */}
                    <td className="py-3 px-4">
                      <p className="font-mono font-bold text-slate-900">{unit.aliquotPercentage.toFixed(2)}%</p>
                      <p className="text-[11px] text-slate-500">{unit.areaSqMeters} m² útiles</p>
                    </td>

                    {/* Parking / Storage */}
                    <td className="py-3 px-4 text-slate-600">
                      <p className="font-medium text-[11px]">{unit.parkingSpots || 'Sin estac.'}</p>
                      <p className="text-[10px] text-slate-400">{unit.storageUnit || 'Sin bodega'}</p>
                    </td>

                    {/* Occupancy */}
                    <td className="py-3 px-4">
                      <span className="text-[11px] font-medium text-slate-700">
                        {unit.occupancyStatus}
                      </span>
                    </td>

                    {/* Balance */}
                    <td className="py-3 px-4 text-right">
                      {isDelinquent ? (
                        <div>
                          <p className="font-bold font-mono text-sm text-rose-600">
                            {settings.currencySymbol} {unit.currentBalance.toFixed(2)}
                          </p>
                          <span className="text-[10px] text-rose-700 font-semibold">
                            {unit.unpaidMonthsCount} mes(es) mora
                          </span>
                        </div>
                      ) : (
                        <div>
                          <p className="font-bold font-mono text-sm text-emerald-600">
                            {unit.currentBalance < 0 ? `-${settings.currencySymbol} ${Math.abs(unit.currentBalance).toFixed(2)}` : `${settings.currencySymbol} 0.00`}
                          </p>
                          <span className="text-[10px] text-emerald-700 font-semibold flex items-center justify-end gap-0.5">
                            <ShieldCheck className="w-3 h-3" /> Solvente
                          </span>
                        </div>
                      )}
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-4">
                      <div className="flex items-center justify-center gap-1.5">
                        {/* Paz y Salvo Official Certificate */}
                        <button
                          onClick={() => setActivePazYSalvoUnit(unit)}
                          className="p-1.5 rounded-md hover:bg-slate-100 text-slate-600 hover:text-slate-900 transition-colors"
                          title="Emitir Certificado Oficial de Paz y Salvo"
                        >
                          <FileCheck className="w-4 h-4 text-amber-600" />
                        </button>

                        {/* Pay */}
                        <button
                          onClick={() => onOpenPaymentModalWithUnit(unit.id)}
                          className="p-1.5 rounded-md hover:bg-emerald-50 text-emerald-600 transition-colors"
                          title="Registrar Cobranza"
                        >
                          <CreditCard className="w-4 h-4" />
                        </button>

                        {/* Edit */}
                        <button
                          onClick={() => onOpenUnitModal(unit)}
                          className="p-1.5 rounded-md hover:bg-slate-100 text-slate-500 hover:text-slate-900 transition-colors"
                          title="Editar Unidad"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>

                        {/* Delete */}
                        <button
                          onClick={() => {
                            if (confirm(`¿Eliminar la unidad ${unit.unitNumber}?`)) {
                              deleteUnit(unit.id);
                            }
                          }}
                          className="p-1.5 rounded-md hover:bg-rose-50 text-rose-500 hover:text-rose-700 transition-colors"
                          title="Eliminar Unidad"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {filtered.length === 0 && (
          <div className="p-8 text-center text-slate-400 text-xs">
            No se encontraron unidades con los filtros seleccionados.
          </div>
        )}

        {/* Table Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>Mostrando {filtered.length} unidades</span>
          <span className="font-mono">Suma de alícuotas filtradas: <strong>{totalAliquot.toFixed(2)}%</strong></span>
        </div>
      </div>
    </div>
  );
};
