import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import {
  CalendarDays,
  Plus,
  Users,
  Clock,
  DollarSign,
  AlertCircle,
  CheckCircle2,
  X,
  Flame,
  Waves,
  PartyPopper,
  Activity,
  Trophy
} from 'lucide-react';
import { Amenity } from '../types/index.ts';

export const AmenitiesView: React.FC = () => {
  const {
    amenities,
    reservations,
    units,
    condominiums,
    selectedCondoId,
    createReservation,
    cancelReservation,
    settings
  } = useApp();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedAmenity, setSelectedAmenity] = useState<Amenity | null>(null);
  const [unitId, setUnitId] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [timeSlot, setTimeSlot] = useState('18:30 a 23:30');

  const filteredAmenities = amenities.filter(a => {
    if (selectedCondoId !== 'all' && a.condoId !== selectedCondoId) return false;
    return true;
  });

  const filteredReservations = reservations.filter(r => {
    if (selectedCondoId !== 'all' && r.condoId !== selectedCondoId) return false;
    return true;
  });

  const handleOpenBooking = (amenity: Amenity) => {
    setSelectedAmenity(amenity);
    setIsModalOpen(true);
  };

  const handleBook = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAmenity || !unitId) return;

    const unit = units.find(u => u.id === unitId);
    if (!unit) return;

    // Strict condo rule: if unit is in mora, warn!
    if (unit.currentBalance > 0) {
      if (!confirm(`La unidad ${unit.unitNumber} registra una deuda de ${settings.currencySymbol} ${unit.currentBalance.toFixed(2)}. Según el Reglamento de Copropiedad, las reservas de áreas comunes requieren estar solvente. ¿Desea autorizar como Administrador la excepción?`)) {
        return;
      }
    }

    createReservation({
      condoId: selectedAmenity.condoId,
      amenityId: selectedAmenity.id,
      amenityName: selectedAmenity.name,
      unitNumber: unit.unitNumber,
      residentName: unit.primaryResidentName,
      date,
      timeSlot,
      totalCost: selectedAmenity.bookingFee + selectedAmenity.cleaningDeposit
    });

    setIsModalOpen(false);
  };

  const renderAmenityIcon = (type: Amenity['iconType']) => {
    switch (type) {
      case 'quincho':
        return <Flame className="w-5 h-5 text-amber-500" />;
      case 'piscina':
        return <Waves className="w-5 h-5 text-sky-500" />;
      case 'salon':
        return <PartyPopper className="w-5 h-5 text-purple-500" />;
      case 'padel':
        return <Trophy className="w-5 h-5 text-emerald-500" />;
      default:
        return <Activity className="w-5 h-5 text-indigo-500" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">
            Áreas Comunes, Amenidades & Reservas
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Gestión de quinchos, salones de eventos, piscinas y canchas deportivas comunitarias.
          </p>
        </div>
      </div>

      {/* Amenities Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {filteredAmenities.map((amenity) => (
          <div
            key={amenity.id}
            className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100">
                  {renderAmenityIcon(amenity.iconType)}
                </div>
                <span className="text-xs font-semibold text-slate-500 flex items-center gap-1">
                  <Users className="w-3.5 h-3.5" /> Aforo {amenity.capacity}
                </span>
              </div>

              <h3 className="font-bold text-slate-900 text-sm mb-1">{amenity.name}</h3>
              <p className="text-xs text-slate-500 line-clamp-2 mb-3">{amenity.rules}</p>

              <div className="space-y-1 text-xs text-slate-600 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                <div className="flex justify-between">
                  <span>Uso / Tarifa:</span>
                  <span className="font-bold text-slate-900 font-mono">
                    {amenity.bookingFee > 0 ? `${settings.currencySymbol} ${amenity.bookingFee.toFixed(2)}` : 'Gratuito'}
                  </span>
                </div>
                {amenity.cleaningDeposit > 0 && (
                  <div className="flex justify-between text-[11px] text-slate-500">
                    <span>Garantía de Aseo:</span>
                    <span>{settings.currencySymbol} {amenity.cleaningDeposit.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-200">
                  <span>Horarios:</span>
                  <span>{amenity.availableHours}</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => handleOpenBooking(amenity)}
              className="mt-4 w-full py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-1.5"
            >
              <CalendarDays className="w-3.5 h-3.5 text-amber-400" />
              Reservar Espacio
            </button>
          </div>
        ))}
      </div>

      {/* Reservations Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <h3 className="font-bold text-slate-900 text-sm">Próximas Reservas Confirmadas</h3>
          <span className="text-xs text-slate-500 font-medium">{filteredReservations.length} activas</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase tracking-wider font-semibold text-[11px]">
                <th className="py-3 px-4">Amenidad / Espacio</th>
                <th className="py-3 px-4">Unidad & Solicitante</th>
                <th className="py-3 px-4">Fecha Agendada</th>
                <th className="py-3 px-4">Franja Horaria</th>
                <th className="py-3 px-4 text-right">Tarifa Abonada</th>
                <th className="py-3 px-4 text-center">Estado</th>
                <th className="py-3 px-4 text-center">Acción</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredReservations.map((resv) => (
                <tr key={resv.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3 px-4 font-bold text-slate-900">
                    {resv.amenityName}
                  </td>
                  <td className="py-3 px-4">
                    <p className="font-semibold text-slate-800">Depto {resv.unitNumber}</p>
                    <p className="text-[11px] text-slate-500">{resv.residentName}</p>
                  </td>
                  <td className="py-3 px-4 text-slate-700 font-medium">
                    {resv.date}
                  </td>
                  <td className="py-3 px-4 text-slate-600">
                    {resv.timeSlot}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                    {settings.currencySymbol} {resv.totalCost.toFixed(2)}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span
                      className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold ${
                        resv.status === 'Confirmada'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {resv.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center">
                    {resv.status === 'Confirmada' && (
                      <button
                        onClick={() => cancelReservation(resv.id)}
                        className="text-xs text-rose-600 hover:text-rose-800 font-semibold"
                      >
                        Cancelar
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Booking Modal */}
      {isModalOpen && selectedAmenity && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="relative w-full max-w-md bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden my-6">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
              <div className="flex items-center gap-2">
                <CalendarDays className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-base">Reservar: {selectedAmenity.name}</h3>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleBook} className="p-6 space-y-4 text-sm">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                  Unidad / Residente que Reserva
                </label>
                <select
                  value={unitId}
                  onChange={(e) => setUnitId(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-medium"
                  required
                >
                  <option value="">Seleccione una unidad...</option>
                  {units.map(u => (
                    <option key={u.id} value={u.id}>
                      Depto {u.unitNumber} - {u.primaryResidentName} (Saldo: {settings.currencySymbol} {u.currentBalance.toFixed(2)})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Fecha de Uso
                  </label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Turno / Horario
                  </label>
                  <select
                    value={timeSlot}
                    onChange={(e) => setTimeSlot(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs"
                  >
                    <option value="12:00 a 17:00">12:00 a 17:00 (Diurno)</option>
                    <option value="18:30 a 23:30">18:30 a 23:30 (Vespertino)</option>
                    <option value="09:00 a 13:00">09:00 a 13:00 (Mañana)</option>
                  </select>
                </div>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs space-y-1">
                <div className="flex justify-between text-slate-600">
                  <span>Costo Reserva:</span>
                  <span>{settings.currencySymbol} {selectedAmenity.bookingFee.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Garantía de Limpieza:</span>
                  <span>{settings.currencySymbol} {selectedAmenity.cleaningDeposit.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-bold text-slate-900 pt-1 border-t border-slate-200">
                  <span>Total a Pagar / Cargar:</span>
                  <span className="font-mono text-emerald-600">
                    {settings.currencySymbol} {(selectedAmenity.bookingFee + selectedAmenity.cleaningDeposit).toFixed(2)}
                  </span>
                </div>
              </div>

              <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-slate-950 bg-amber-500 hover:bg-amber-600 rounded-lg shadow-xs transition-colors"
                >
                  Confirmar Reserva
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
