import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import {
  Wrench,
  Plus,
  AlertCircle,
  Clock,
  CheckCircle2,
  Calendar,
  X,
  Filter
} from 'lucide-react';
import { MaintenanceTicket } from '../types/index.ts';

export const MaintenanceView: React.FC = () => {
  const {
    tickets,
    condominiums,
    selectedCondoId,
    createTicket,
    updateTicketStatus,
    settings
  } = useApp();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [filterPriority, setFilterPriority] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Form
  const [condoId, setCondoId] = useState(selectedCondoId === 'all' ? condominiums[0]?.id : selectedCondoId);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [category, setCategory] = useState<MaintenanceTicket['category']>('Ascensores');
  const [priority, setPriority] = useState<MaintenanceTicket['priority']>('Media');
  const [assignedTo, setAssignedTo] = useState('Servicio Técnico Especializado');
  const [estimatedCost, setEstimatedCost] = useState(100);

  const filteredTickets = tickets.filter(t => {
    if (selectedCondoId !== 'all' && t.condoId !== selectedCondoId) return false;
    if (filterPriority !== 'all' && t.priority !== filterPriority) return false;
    if (filterStatus !== 'all' && t.status !== filterStatus) return false;
    return true;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !location) return;

    createTicket({
      condoId: condoId || condominiums[0]?.id,
      title,
      description,
      location,
      category,
      priority,
      assignedTo,
      reportedBy: 'Administración Condolink V20.8',
      estimatedCost: Number(estimatedCost)
    });

    setIsModalOpen(false);
    setTitle('');
    setDescription('');
    setLocation('');
  };

  return (
    <div className="space-y-5">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">
            Mantenimiento & Bitácora de Incidencias Operativas
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Supervisión técnica de ascensores, salas de bombas, grupos electrógenos y áreas comunes.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 transition-colors shadow-xs shrink-0"
        >
          <Plus className="w-4 h-4" />
          Reportar Incidencia
        </button>
      </div>

      {/* Filters Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-wrap items-center gap-3 text-xs">
        <span className="font-semibold text-slate-500">Filtrar por:</span>
        <select
          value={filterPriority}
          onChange={(e) => setFilterPriority(e.target.value)}
          className="px-3 py-1.5 border border-slate-200 rounded-lg text-slate-700 bg-white"
        >
          <option value="all">Todas las Prioridades</option>
          <option value="Urgente">Urgente</option>
          <option value="Alta">Alta</option>
          <option value="Media">Media</option>
          <option value="Baja">Baja</option>
        </select>

        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="px-3 py-1.5 border border-slate-200 rounded-lg text-slate-700 bg-white"
        >
          <option value="all">Todos los Estados</option>
          <option value="Reportado">Reportado</option>
          <option value="En Proceso">En Proceso</option>
          <option value="Resuelto">Resuelto</option>
        </select>

        <span className="text-slate-400 ml-auto">
          {filteredTickets.length} incidencias encontradas
        </span>
      </div>

      {/* Tickets List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTickets.map((tkt) => {
          const isResolved = tkt.status === 'Resuelto';

          return (
            <div
              key={tkt.id}
              className={`bg-white rounded-xl border p-5 shadow-xs flex flex-col justify-between transition-all ${
                tkt.priority === 'Urgente'
                  ? 'border-rose-300 ring-1 ring-rose-200'
                  : 'border-slate-200'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                      tkt.priority === 'Urgente'
                        ? 'bg-rose-100 text-rose-800'
                        : tkt.priority === 'Alta'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    {tkt.priority}
                  </span>
                  <span className="text-[11px] font-semibold text-slate-400">
                    {tkt.category}
                  </span>
                </div>

                <h3 className="font-bold text-slate-900 text-sm leading-snug">{tkt.title}</h3>
                <p className="text-xs text-slate-600 mt-2 line-clamp-2">{tkt.description}</p>

                <div className="mt-4 pt-3 border-t border-slate-100 space-y-1 text-[11px] text-slate-500">
                  <p><span className="font-semibold text-slate-700">Ubicación:</span> {tkt.location}</p>
                  <p><span className="font-semibold text-slate-700">Asignado a:</span> {tkt.assignedTo}</p>
                  <p><span className="font-semibold text-slate-700">Costo Estimado:</span> {settings.currencySymbol} {tkt.estimatedCost}</p>
                  {tkt.resolutionDate && (
                    <p className="text-emerald-600 font-semibold">Resuelto el {tkt.resolutionDate}</p>
                  )}
                </div>
              </div>

              {/* Status footer button */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                <span
                  className={`text-[11px] font-bold ${
                    isResolved ? 'text-emerald-600' : 'text-amber-600'
                  }`}
                >
                  {tkt.status}
                </span>

                {!isResolved ? (
                  <div className="flex items-center gap-1.5">
                    {tkt.status === 'Reportado' && (
                      <button
                        onClick={() => updateTicketStatus(tkt.id, 'En Proceso')}
                        className="px-2.5 py-1 text-xs bg-slate-100 hover:bg-slate-200 text-slate-800 rounded font-medium transition-colors"
                      >
                        Iniciar
                      </button>
                    )}
                    <button
                      onClick={() => updateTicketStatus(tkt.id, 'Resuelto', tkt.estimatedCost)}
                      className="px-2.5 py-1 text-xs bg-emerald-600 hover:bg-emerald-700 text-white rounded font-bold transition-colors"
                    >
                      Completar
                    </button>
                  </div>
                ) : (
                  <span className="text-xs text-slate-400 font-medium flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" /> Cerrado
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Ticket Create Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="relative w-full max-w-lg bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden my-6">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
              <div className="flex items-center gap-2">
                <Wrench className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-base">Reportar Nueva Incidencia Técnica</h3>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-sm">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                  Condominio
                </label>
                <select
                  value={condoId}
                  onChange={(e) => setCondoId(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-medium"
                >
                  {condominiums.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                  Título de la Falla / Incidencia
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ej. Fuga de agua en tubería de riego Torre B"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Categoría
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs"
                  >
                    <option value="Ascensores">Ascensores</option>
                    <option value="Bombas de Agua">Bombas de Agua</option>
                    <option value="Electricidad">Electricidad</option>
                    <option value="Piscina/Áreas Verdes">Piscina / Áreas Verdes</option>
                    <option value="Cerrajería/Portón">Portón / Cerrajería</option>
                    <option value="Estructural">Estructural</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Prioridad
                  </label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs font-medium"
                  >
                    <option value="Baja">Baja</option>
                    <option value="Media">Media</option>
                    <option value="Alta">Alta</option>
                    <option value="Urgente">Urgente</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Ubicación Específica
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Ej. Sala de Calderas - Sub 1"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Costo Estimado ({settings.currencySymbol})
                  </label>
                  <input
                    type="number"
                    value={estimatedCost}
                    onChange={(e) => setEstimatedCost(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                  Técnico / Empresa Asignada
                </label>
                <input
                  type="text"
                  placeholder="Ej. Hidráulica Chile Ltda."
                  value={assignedTo}
                  onChange={(e) => setAssignedTo(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                  Descripción Detallada
                </label>
                <textarea
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Detalles sobre el síntoma, impacto en copropietarios..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs"
                />
              </div>

              <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-slate-950 bg-amber-500 hover:bg-amber-600 rounded-lg shadow-xs transition-colors"
                >
                  Crear Incidencia
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
