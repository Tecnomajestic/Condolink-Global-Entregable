import React from 'react';
import { useApp } from '../context/AppContext.tsx';
import {
  UserCheck,
  Building,
  CreditCard,
  FileCheck,
  Calendar,
  Package,
  Wrench,
  ShieldCheck,
  AlertTriangle,
  Receipt,
  Download,
  CheckCircle2
} from 'lucide-react';

interface ResidentPortalViewProps {
  onOpenPaymentModalWithUnit: (unitId: string) => void;
}

export const ResidentPortalView: React.FC<ResidentPortalViewProps> = ({
  onOpenPaymentModalWithUnit
}) => {
  const {
    units,
    condominiums,
    selectedResidentUnitId,
    setSelectedResidentUnitId,
    invoices,
    payments,
    reservations,
    packages,
    tickets,
    settings,
    setActiveReceipt,
    setActivePazYSalvoUnit
  } = useApp();

  const currentUnit = units.find(u => u.id === selectedResidentUnitId) || units[0];
  const condo = condominiums.find(c => c.id === currentUnit?.condoId);

  const unitInvoices = invoices.filter(i => i.unitId === currentUnit?.id);
  const unitPayments = payments.filter(p => p.unitId === currentUnit?.id);
  const unitReservations = reservations.filter(r => r.unitNumber === currentUnit?.unitNumber);
  const unitPackages = packages.filter(p => p.unitNumber === currentUnit?.unitNumber);

  const isSolvent = currentUnit ? currentUnit.currentBalance <= 0 : false;

  return (
    <div className="space-y-6">
      {/* Selector of which resident account you are previewing */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 text-white flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-amber-400 text-slate-950">
            Vista Autoservicio Copropietario
          </span>
          <h1 className="text-xl font-black text-white mt-2">
            Portal del Residente · Depto {currentUnit?.unitNumber}
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            {currentUnit?.primaryResidentName} · {condo?.name} ({currentUnit?.towerOrBlock})
          </p>
        </div>

        {/* Change Unit Simulator */}
        <div className="bg-slate-800/80 p-2.5 rounded-lg border border-slate-700/80 flex items-center gap-2">
          <span className="text-xs text-slate-300 font-medium">Ver como:</span>
          <select
            value={selectedResidentUnitId}
            onChange={(e) => setSelectedResidentUnitId(e.target.value)}
            className="bg-slate-900 text-amber-300 font-bold px-3 py-1.5 rounded-md text-xs border border-slate-700 focus:outline-none"
          >
            {units.map(u => (
              <option key={u.id} value={u.id}>
                Unidad {u.unitNumber} - {u.primaryResidentName} ({u.paymentStatus})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Financial Status Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Balance Card */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <span className="text-xs uppercase font-bold tracking-wider text-slate-400 block mb-1">
            Estado de Cuenta
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className={`text-3xl font-black font-mono ${isSolvent ? 'text-emerald-600' : 'text-rose-600'}`}>
              {settings.currencySymbol} {currentUnit?.currentBalance.toFixed(2)}
            </span>
          </div>

          <div className="mt-3 flex items-center gap-2">
            {isSolvent ? (
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Al Día y Solvente
              </span>
            ) : (
              <span className="text-xs font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" /> Pago Pendiente ({currentUnit?.unpaidMonthsCount} meses)
              </span>
            )}
          </div>

          <div className="mt-4 pt-4 border-t border-slate-100 flex items-center gap-2">
            {!isSolvent && (
              <button
                onClick={() => onOpenPaymentModalWithUnit(currentUnit.id)}
                className="w-full py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-1.5"
              >
                <CreditCard className="w-4 h-4" />
                Pagar Gasto Común Online
              </button>
            )}
            <button
              onClick={() => setActivePazYSalvoUnit(currentUnit)}
              className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded-lg transition-colors flex items-center justify-center gap-1.5"
            >
              <FileCheck className="w-4 h-4 text-amber-400" />
              Descargar Paz y Salvo
            </button>
          </div>
        </div>

        {/* Unit Data */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs text-xs space-y-2.5">
          <span className="text-xs uppercase font-bold tracking-wider text-slate-400 block">
            Ficha de la Propiedad
          </span>
          <div className="flex justify-between py-1 border-b border-slate-100">
            <span className="text-slate-500">Alícuota Legal:</span>
            <span className="font-bold font-mono text-slate-900">{currentUnit?.aliquotPercentage}%</span>
          </div>
          <div className="flex justify-between py-1 border-b border-slate-100">
            <span className="text-slate-500">Superficie Útil:</span>
            <span className="font-semibold text-slate-800">{currentUnit?.areaSqMeters} m²</span>
          </div>
          <div className="flex justify-between py-1 border-b border-slate-100">
            <span className="text-slate-500">Estacionamiento:</span>
            <span className="font-semibold text-slate-800">{currentUnit?.parkingSpots || 'Ninguno'}</span>
          </div>
          <div className="flex justify-between py-1 border-b border-slate-100">
            <span className="text-slate-500">Bodega Asignada:</span>
            <span className="font-semibold text-slate-800">{currentUnit?.storageUnit || 'Ninguna'}</span>
          </div>
          <div className="flex justify-between py-1">
            <span className="text-slate-500">Condición:</span>
            <span className="font-semibold text-slate-800">{currentUnit?.occupancyStatus}</span>
          </div>
        </div>

        {/* Packages & Deliveries */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs uppercase font-bold tracking-wider text-slate-400 block">
              Encomiendas en Portería
            </span>
            <Package className="w-4 h-4 text-amber-500" />
          </div>

          {unitPackages.length > 0 ? (
            <div className="space-y-2">
              {unitPackages.map(p => (
                <div key={p.id} className="p-2.5 rounded-lg bg-slate-50 border border-slate-100 text-xs">
                  <div className="flex justify-between font-bold text-slate-900 mb-0.5">
                    <span>{p.courier}</span>
                    <span className={p.status === 'En Conserjería' ? 'text-amber-600' : 'text-emerald-600'}>
                      {p.status}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500">{p.description} ({p.trackingNumber})</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-slate-400 italic py-4 text-center">
              No tienes paquetes pendientes por retirar en conserjería.
            </p>
          )}
        </div>
      </div>

      {/* Invoices & Payment History */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200">
          <h3 className="font-bold text-slate-900 text-sm">Historial de Boletas & Gastos Comunes</h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase tracking-wider font-semibold text-[11px]">
                <th className="py-3 px-4">N° Boleta</th>
                <th className="py-3 px-4">Período</th>
                <th className="py-3 px-4">Fecha Vencimiento</th>
                <th className="py-3 px-4 text-right">Monto Total</th>
                <th className="py-3 px-4 text-center">Estado</th>
                <th className="py-3 px-4 text-center">Comprobante</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {unitInvoices.map((inv) => (
                <tr key={inv.id} className="hover:bg-slate-50/70">
                  <td className="py-3 px-4 font-mono font-bold text-slate-900">{inv.invoiceNumber}</td>
                  <td className="py-3 px-4 font-medium text-slate-800">{inv.period}</td>
                  <td className="py-3 px-4 text-slate-600">{inv.dueDate}</td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                    {settings.currencySymbol} {inv.totalAmount.toFixed(2)}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span
                      className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold ${
                        inv.status === 'Pagado'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {inv.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center">
                    {inv.status === 'Pagado' && (
                      <button
                        onClick={() => {
                          const p = payments.find(pay => pay.unitId === currentUnit.id);
                          if (p) setActiveReceipt(p);
                        }}
                        className="text-xs font-semibold text-amber-600 hover:text-amber-700 inline-flex items-center gap-1"
                      >
                        <Receipt className="w-3.5 h-3.5" />
                        Ver Recibo
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
