import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { Building2, Plus, MapPin, Mail, Landmark, Percent, ShieldCheck, Check, X } from 'lucide-react';
import { Condominium } from '../types/index.ts';

export const CondosView: React.FC = () => {
  const { condominiums, addCondominium, units, setSelectedCondoId, settings } = useApp();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [totalUnits, setTotalUnits] = useState(30);
  const [administrator, setAdministrator] = useState('Condolink Global Ejecutivo');
  const [adminEmail, setAdminEmail] = useState('condolinkglobal@gmail.com');
  const [taxId, setTaxId] = useState('');
  const [bankName, setBankName] = useState('Banco Santander');
  const [bankAccount, setBankAccount] = useState('Cta. Corriente #');
  const [reserveFundPercentage, setReserveFundPercentage] = useState(5);
  const [defaultLateFeePercentage, setDefaultLateFeePercentage] = useState(2.5);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !code) return;

    addCondominium({
      name,
      code,
      address,
      city,
      totalUnits: Number(totalUnits),
      administrator,
      adminEmail,
      taxId: taxId || `CL-76.${Math.floor(100 + Math.random() * 899)}.${Math.floor(100 + Math.random() * 899)}-K`,
      bankName,
      bankAccount,
      currency: settings.currencyCode,
      reserveFundPercentage: Number(reserveFundPercentage),
      defaultLateFeePercentage: Number(defaultLateFeePercentage)
    });

    setIsModalOpen(false);
    setName('');
    setCode('');
    setAddress('');
    setCity('');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">
            Gestión de Inmuebles, Condominios & Torres
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Administración centralizada de comunidades, cuentas bancarias operativas y reglamentos.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 transition-colors shadow-xs shrink-0"
        >
          <Plus className="w-4 h-4" />
          Incorporar Nuevo Condominio
        </button>
      </div>

      {/* Condominium Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {condominiums.map((condo) => {
          const condoUnits = units.filter(u => u.condoId === condo.id);
          const delinquentCount = condoUnits.filter(u => u.currentBalance > 0).length;
          const totalDelinquent = condoUnits.reduce((acc, u) => u.currentBalance > 0 ? acc + u.currentBalance : acc, 0);

          return (
            <div
              key={condo.id}
              className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs hover:border-slate-300 transition-all flex flex-col justify-between"
            >
              <div className="p-5">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-lg bg-slate-900 text-amber-400 flex items-center justify-center font-bold text-base shrink-0">
                      {condo.code.substring(0, 3)}
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-900 text-sm">{condo.name}</h3>
                      <span className="text-[11px] font-mono text-slate-400">ID: {condo.taxId}</span>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded">
                    Activo V20.8
                  </span>
                </div>

                <div className="space-y-2 text-xs text-slate-600 mt-4">
                  <p className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{condo.address}, {condo.city}</span>
                  </p>
                  <p className="flex items-center gap-1.5">
                    <Landmark className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{condo.bankName} · {condo.bankAccount}</span>
                  </p>
                  <p className="flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{condo.adminEmail}</span>
                  </p>
                </div>

                {/* Sub metrics */}
                <div className="mt-5 pt-4 border-t border-slate-100 grid grid-cols-2 gap-2 text-center text-xs">
                  <div className="p-2 bg-slate-50 rounded-lg">
                    <span className="text-slate-400 text-[10px] uppercase font-bold block">Unidades</span>
                    <span className="font-bold text-slate-900">{condoUnits.length} / {condo.totalUnits}</span>
                  </div>
                  <div className="p-2 bg-slate-50 rounded-lg">
                    <span className="text-slate-400 text-[10px] uppercase font-bold block">Cartera Morosa</span>
                    <span className={`font-bold ${delinquentCount > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                      {settings.currencySymbol} {totalDelinquent.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Bottom bar */}
              <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] text-slate-500">
                  Fondo Reserva: <strong>{condo.reserveFundPercentage}%</strong>
                </span>
                <button
                  onClick={() => setSelectedCondoId(condo.id)}
                  className="px-3 py-1 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-md transition-colors"
                >
                  Administrar →
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Condo Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="relative w-full max-w-lg bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden my-6">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-base">Incorporar Nuevo Inmueble / Condominio</h3>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-sm">
              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-2">
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Nombre del Condominio / Edificio
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Ej. Torres del Mar"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Código Breve
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="TDM-04"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono font-bold focus:outline-none focus:ring-2 focus:ring-amber-500 uppercase"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Dirección
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Av. Providencia 1200"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Ciudad / Comuna
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Santiago"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Banco de Operación
                  </label>
                  <input
                    type="text"
                    value={bankName}
                    onChange={(e) => setBankName(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Cuenta Corriente
                  </label>
                  <input
                    type="text"
                    value={bankAccount}
                    onChange={(e) => setBankAccount(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Fondo Reserva (%)
                  </label>
                  <input
                    type="number"
                    value={reserveFundPercentage}
                    onChange={(e) => setReserveFundPercentage(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Interés Mora (%)
                  </label>
                  <input
                    type="number"
                    value={defaultLateFeePercentage}
                    onChange={(e) => setDefaultLateFeePercentage(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-slate-950 bg-amber-500 hover:bg-amber-600 rounded-lg shadow-xs transition-colors"
                >
                  Incorporar Inmueble
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
