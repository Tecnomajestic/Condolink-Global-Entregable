import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import {
  Vote,
  Users,
  Calendar,
  CheckCircle2,
  Clock,
  ThumbsUp,
  ThumbsDown,
  MinusCircle,
  Award,
  Plus,
  X
} from 'lucide-react';
import { AssemblyMeeting } from '../types/index.ts';

export const AssembliesView: React.FC = () => {
  const { assemblies, castVote, selectedCondoId, condominiums } = useApp();

  const filteredAssemblies = assemblies.filter(a => {
    if (selectedCondoId !== 'all' && a.condoId !== selectedCondoId) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">
            Asambleas de Copropietarios & Votaciones Telemáticas
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Cálculo de quórum legal en base a alícuotas (%), acuerdos comunitarios y actas oficiales.
          </p>
        </div>
      </div>

      {/* Assembly Cards */}
      <div className="space-y-6">
        {filteredAssemblies.map((assembly) => {
          const isQuorumReached = assembly.currentQuorumPercentage >= assembly.quorumRequiredPercentage;

          return (
            <div
              key={assembly.id}
              className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden"
            >
              {/* Header */}
              <div className="p-6 bg-slate-900 text-white flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-amber-400 text-slate-950">
                      Asamblea {assembly.type}
                    </span>
                    <span className="text-slate-400 text-xs">·</span>
                    <span className="text-xs text-slate-300 font-mono">
                      {assembly.date} a las {assembly.time}
                    </span>
                  </div>
                  <h2 className="text-lg font-bold text-white tracking-tight">{assembly.title}</h2>
                  <p className="text-xs text-slate-400 mt-1">{assembly.location}</p>
                </div>

                {/* Quorum Badge */}
                <div className="bg-slate-800/80 p-3 rounded-lg border border-slate-700/80 text-center min-w-[160px]">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Quórum de Asistencia</span>
                  <div className="text-2xl font-black font-mono text-amber-400 mt-0.5">
                    {assembly.currentQuorumPercentage.toFixed(1)}%
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1 flex items-center justify-center gap-1">
                    {isQuorumReached ? (
                      <span className="text-emerald-400 font-semibold flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Quórum Válido (&gt;{assembly.quorumRequiredPercentage}%)
                      </span>
                    ) : (
                      <span className="text-rose-400 font-semibold">
                        Insuficiente (Requiere {assembly.quorumRequiredPercentage}%)
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Agenda & Votes */}
              <div className="p-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Agenda Points */}
                <div>
                  <h3 className="font-bold text-slate-900 text-xs uppercase tracking-wider mb-3">
                    Tabla de Puntos a Tratar (Orden del Día)
                  </h3>
                  <ul className="space-y-2 text-xs text-slate-700 bg-slate-50 p-4 rounded-lg border border-slate-200">
                    {assembly.agenda.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="font-bold text-slate-400">•</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Live Voting Section */}
                <div>
                  <h3 className="font-bold text-slate-900 text-xs uppercase tracking-wider mb-3">
                    Votaciones Activas en Plenario
                  </h3>
                  <div className="space-y-4">
                    {assembly.votes.map((vote) => (
                      <div key={vote.id} className="p-4 rounded-lg border border-slate-200 bg-white shadow-2xs space-y-3">
                        <p className="font-bold text-slate-900 text-xs">{vote.topic}</p>

                        {/* Bar chart of votes */}
                        <div className="space-y-1.5 text-[11px]">
                          <div>
                            <div className="flex justify-between font-semibold text-emerald-700">
                              <span>A Favor:</span>
                              <span>{vote.inFavorPercent.toFixed(1)}%</span>
                            </div>
                            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                              <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${vote.inFavorPercent}%` }}></div>
                            </div>
                          </div>

                          <div>
                            <div className="flex justify-between font-semibold text-rose-700">
                              <span>En Contra:</span>
                              <span>{vote.againstPercent.toFixed(1)}%</span>
                            </div>
                            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                              <div className="bg-rose-500 h-full rounded-full" style={{ width: `${vote.againstPercent}%` }}></div>
                            </div>
                          </div>

                          <div>
                            <div className="flex justify-between font-semibold text-slate-500">
                              <span>Abstención:</span>
                              <span>{vote.abstainPercent.toFixed(1)}%</span>
                            </div>
                            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                              <div className="bg-slate-400 h-full rounded-full" style={{ width: `${vote.abstainPercent}%` }}></div>
                            </div>
                          </div>
                        </div>

                        {/* Casting Vote Buttons */}
                        <div className="pt-2 border-t border-slate-100 flex items-center justify-end gap-2">
                          <button
                            onClick={() => castVote(assembly.id, vote.id, 'favor')}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200 transition-colors"
                          >
                            <ThumbsUp className="w-3 h-3 text-emerald-600" />
                            A Favor
                          </button>
                          <button
                            onClick={() => castVote(assembly.id, vote.id, 'contra')}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded bg-rose-50 text-rose-800 hover:bg-rose-100 border border-rose-200 transition-colors"
                          >
                            <ThumbsDown className="w-3 h-3 text-rose-600" />
                            En Contra
                          </button>
                          <button
                            onClick={() => castVote(assembly.id, vote.id, 'abstencion')}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200 transition-colors"
                          >
                            <MinusCircle className="w-3 h-3 text-slate-500" />
                            Abstención
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
