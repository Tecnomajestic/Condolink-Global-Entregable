import React from 'react';
import { useApp } from '../context/AppContext.tsx';
import {
  TrendingUp,
  AlertTriangle,
  Building,
  CheckCircle2,
  DollarSign,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
  Users,
  Wrench,
  Receipt,
  FileCheck,
  ShieldAlert
} from 'lucide-react';

interface DashboardViewProps {
  onOpenPaymentModal: () => void;
  onOpenExpenseModal: () => void;
  onOpenInvoiceModal: () => void;
  onNavigate: (view: any) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onOpenPaymentModal,
  onOpenExpenseModal,
  onOpenInvoiceModal,
  onNavigate
}) => {
  const {
    condominiums,
    selectedCondoId,
    units,
    invoices,
    payments,
    expenses,
    tickets,
    packages,
    settings,
    setActiveReceipt,
    setActivePazYSalvoUnit
  } = useApp();

  // Filter based on selected condo
  const filteredUnits = selectedCondoId === 'all'
    ? units
    : units.filter(u => u.condoId === selectedCondoId);

  const filteredInvoices = selectedCondoId === 'all'
    ? invoices
    : invoices.filter(i => i.condoId === selectedCondoId);

  const filteredPayments = selectedCondoId === 'all'
    ? payments
    : payments.filter(p => p.condoId === selectedCondoId);

  const filteredExpenses = selectedCondoId === 'all'
    ? expenses
    : expenses.filter(e => e.condoId === selectedCondoId);

  const filteredTickets = selectedCondoId === 'all'
    ? tickets
    : tickets.filter(t => t.condoId === selectedCondoId);

  // Financial calculations
  const totalBilled = filteredInvoices.reduce((acc, inv) => acc + inv.totalAmount, 0);
  const totalCollected = filteredPayments.reduce((acc, pay) => acc + pay.amount, 0);
  const totalExpenses = filteredExpenses.reduce((acc, exp) => acc + exp.amount, 0);
  const netCashFlow = totalCollected - totalExpenses;

  const totalDelinquentAmount = filteredUnits.reduce((acc, u) => (u.currentBalance > 0 ? acc + u.currentBalance : acc), 0);
  const delinquentUnitsCount = filteredUnits.filter(u => u.currentBalance > 0).length;
  const collectionRate = totalBilled > 0 ? Math.min(100, Math.round((totalCollected / totalBilled) * 100)) : 100;

  // Urgent alerts
  const urgentTickets = filteredTickets.filter(t => t.priority === 'Urgente' || t.priority === 'Alta');
  const criticalDebtors = filteredUnits.filter(u => u.unpaidMonthsCount >= 2);
  const pendingPackages = packages.filter(p => p.status === 'En Conserjería');

  return (
    <div className="space-y-6">
      {/* Top Banner / Welcome */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-xl p-5 text-white shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase font-bold tracking-wider text-amber-400">
              Sistema Ejecutivo de Copropiedad
            </span>
            <span className="text-slate-600">·</span>
            <span className="text-xs text-slate-400">Edición V20.8 Desacoplada</span>
          </div>
          <h1 className="text-xl font-black text-white mt-0.5">
            Panel de Control Ejecutivo & Conciliación
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Gestión financiera, estado de cuentas de copropietarios, operaciones y auditoría en tiempo real.
          </p>
        </div>

        {/* Quick action buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onOpenInvoiceModal}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 transition-colors"
          >
            <Calendar className="w-3.5 h-3.5" />
            Emisión de Gastos Comunes
          </button>
          <button
            onClick={onOpenPaymentModal}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 transition-colors shadow-xs"
          >
            <DollarSign className="w-3.5 h-3.5" />
            Registrar Cobro
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Recaudación del Mes */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Recaudación Real
            </span>
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-2xl font-black text-slate-900">
              {settings.currencySymbol} {totalCollected.toLocaleString('es-CL', { minimumFractionDigits: 2 })}
            </span>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
            <span>Tasa de Cobranza:</span>
            <span className="font-bold text-emerald-600">{collectionRate}% efectividad</span>
          </div>
        </div>

        {/* Cuentas por Cobrar / Cartera Vencida */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Cartera Morosa
            </span>
            <div className="p-2 rounded-lg bg-rose-50 text-rose-600">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-2xl font-black text-rose-600">
              {settings.currencySymbol} {totalDelinquentAmount.toLocaleString('es-CL', { minimumFractionDigits: 2 })}
            </span>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
            <span>Unidades en mora:</span>
            <span className="font-semibold text-rose-700">
              {delinquentUnitsCount} de {filteredUnits.length} ({Math.round((delinquentUnitsCount / (filteredUnits.length || 1)) * 100)}%)
            </span>
          </div>
        </div>

        {/* Egresos Operativos */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Egresos Operativos
            </span>
            <div className="p-2 rounded-lg bg-amber-50 text-amber-600">
              <ArrowDownRight className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-2xl font-black text-slate-900">
              {settings.currencySymbol} {totalExpenses.toLocaleString('es-CL', { minimumFractionDigits: 2 })}
            </span>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
            <span>Proveedores afectos:</span>
            <span className="font-semibold text-slate-700">{filteredExpenses.length} facturas</span>
          </div>
        </div>

        {/* Flujo de Caja Neto */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Superávit / Flujo Neto
            </span>
            <div className={`p-2 rounded-lg ${netCashFlow >= 0 ? 'bg-indigo-50 text-indigo-600' : 'bg-rose-50 text-rose-600'}`}>
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-1">
            <span className={`text-2xl font-black ${netCashFlow >= 0 ? 'text-indigo-600' : 'text-rose-600'}`}>
              {settings.currencySymbol} {netCashFlow.toLocaleString('es-CL', { minimumFractionDigits: 2 })}
            </span>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
            <span>Fondo Reserva (5%):</span>
            <span className="font-semibold text-slate-700">
              {settings.currencySymbol} {(totalCollected * 0.05).toFixed(2)}
            </span>
          </div>
        </div>
      </div>

      {/* Main Content: Cash Flow & Urgent Executive Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Cash Flow & Financial Breakdown */}
        <div className="lg:col-span-2 space-y-6">
          {/* Monthly Comparison */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-bold text-slate-900 text-sm">Flujo Financiero Comparativo (Ingresos vs Egresos)</h3>
                <p className="text-xs text-slate-500">Resumen contable acumulado para el período en curso</p>
              </div>
              <button
                onClick={() => onNavigate('finance')}
                className="text-xs font-semibold text-amber-600 hover:text-amber-700"
              >
                Ver Contabilidad Completa →
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-xs font-medium mb-1.5">
                  <span className="text-slate-600">Total Facturado / Emitido</span>
                  <span className="font-bold text-slate-900 font-mono">
                    {settings.currencySymbol} {totalBilled.toFixed(2)}
                  </span>
                </div>
                <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                  <div className="bg-slate-400 h-full rounded-full" style={{ width: '100%' }}></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-medium mb-1.5">
                  <span className="text-slate-600">Ingresos Percibidos (Cobranzas)</span>
                  <span className="font-bold text-emerald-600 font-mono">
                    {settings.currencySymbol} {totalCollected.toFixed(2)} ({collectionRate}%)
                  </span>
                </div>
                <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                  <div
                    className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                    style={{ width: `${Math.min(100, collectionRate)}%` }}
                  ></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-medium mb-1.5">
                  <span className="text-slate-600">Egresos & Cuentas por Pagar</span>
                  <span className="font-bold text-amber-600 font-mono">
                    {settings.currencySymbol} {totalExpenses.toFixed(2)}
                  </span>
                </div>
                <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                  <div
                    className="bg-amber-500 h-full rounded-full transition-all duration-500"
                    style={{ width: `${Math.min(100, totalBilled > 0 ? (totalExpenses / totalBilled) * 100 : 50)}%` }}
                  ></div>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 grid grid-cols-3 gap-2 text-center text-xs">
              <div className="p-2 bg-slate-50 rounded-lg">
                <span className="text-slate-400 text-[10px] uppercase font-bold block">Unidades</span>
                <span className="font-bold text-slate-800 text-sm">{filteredUnits.length}</span>
              </div>
              <div className="p-2 bg-slate-50 rounded-lg">
                <span className="text-slate-400 text-[10px] uppercase font-bold block">Solvencia</span>
                <span className="font-bold text-emerald-600 text-sm">
                  {filteredUnits.length - delinquentUnitsCount} ({Math.round(((filteredUnits.length - delinquentUnitsCount) / (filteredUnits.length || 1)) * 100)}%)
                </span>
              </div>
              <div className="p-2 bg-slate-50 rounded-lg">
                <span className="text-slate-400 text-[10px] uppercase font-bold block">Incidencias</span>
                <span className="font-bold text-slate-800 text-sm">{filteredTickets.length} activas</span>
              </div>
            </div>
          </div>

          {/* Recent Payments Stream */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-bold text-slate-900 text-sm">Últimos Pagos Registrados</h3>
                <p className="text-xs text-slate-500">Comprobantes oficiales de ingreso con QR y timbrado</p>
              </div>
              <span className="text-xs font-semibold text-slate-400">{filteredPayments.length} registros</span>
            </div>

            <div className="divide-y divide-slate-100">
              {filteredPayments.slice(0, 5).map((pay) => (
                <div key={pay.id} className="py-3 flex items-center justify-between gap-4">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-xs text-slate-900">Unidad {pay.unitNumber}</span>
                      <span className="text-slate-400">·</span>
                      <span className="text-xs text-slate-600 truncate">{pay.payerName}</span>
                    </div>
                    <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                      <span className="font-mono">{pay.receiptNumber}</span>
                      <span>·</span>
                      <span>{pay.paymentMethod}</span>
                      <span>·</span>
                      <span>{pay.paymentDate}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <span className="font-bold text-emerald-600 text-sm">
                      +{settings.currencySymbol} {pay.amount.toFixed(2)}
                    </span>
                    <button
                      onClick={() => setActiveReceipt(pay)}
                      className="px-2.5 py-1 text-[11px] font-semibold bg-slate-100 hover:bg-slate-200 text-slate-800 rounded transition-colors"
                      title="Ver e imprimir recibo oficial"
                    >
                      Recibo
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right 1 Col: Urgent Attention Alerts */}
        <div className="space-y-6">
          {/* Delinquency Alert Card */}
          <div className="bg-white rounded-xl border border-rose-200 p-5 shadow-xs">
            <div className="flex items-center gap-2 text-rose-600 mb-3">
              <ShieldAlert className="w-5 h-5" />
              <h3 className="font-bold text-slate-900 text-sm">Gestión de Cobranza Prioritaria</h3>
            </div>
            <p className="text-xs text-slate-500 mb-4">
              Copropietarios con saldo deudor pendiente de regularización:
            </p>

            <div className="space-y-2.5">
              {criticalDebtors.length > 0 ? (
                criticalDebtors.map(debtor => (
                  <div key={debtor.id} className="p-3 rounded-lg bg-rose-50/60 border border-rose-100 flex items-center justify-between text-xs">
                    <div>
                      <p className="font-bold text-slate-900">Depto {debtor.unitNumber} · {debtor.primaryResidentName}</p>
                      <p className="text-[11px] text-rose-700 mt-0.5">
                        {debtor.unpaidMonthsCount} meses en mora ({settings.currencySymbol} {debtor.currentBalance.toFixed(2)})
                      </p>
                    </div>
                    <button
                      onClick={onOpenPaymentModal}
                      className="px-2 py-1 bg-white border border-rose-300 hover:bg-rose-100 text-rose-800 font-bold rounded text-[11px] transition-colors"
                    >
                      Cobrar
                    </button>
                  </div>
                ))
              ) : (
                <div className="p-4 text-center rounded-lg bg-emerald-50 text-emerald-800 text-xs">
                  <CheckCircle2 className="w-5 h-5 mx-auto mb-1 text-emerald-600" />
                  No existen deudores críticos mayores a 60 días.
                </div>
              )}
            </div>
          </div>

          {/* Pending Maintenance */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Wrench className="w-4 h-4 text-amber-500" />
                <h3 className="font-bold text-slate-900 text-sm">Incidencias Operativas</h3>
              </div>
              <button
                onClick={() => onNavigate('maintenance')}
                className="text-xs font-semibold text-amber-600 hover:text-amber-700"
              >
                Ver todas →
              </button>
            </div>

            <div className="space-y-3">
              {filteredTickets.slice(0, 3).map(t => (
                <div key={t.id} className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-slate-900 truncate">{t.title}</span>
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                      t.priority === 'Urgente' || t.priority === 'Alta' ? 'bg-rose-100 text-rose-700' : 'bg-slate-200 text-slate-700'
                    }`}>
                      {t.priority}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 line-clamp-1">{t.location} · {t.assignedTo}</p>
                  <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2 pt-2 border-t border-slate-200">
                    <span>Estado: <strong className="text-slate-700">{t.status}</strong></span>
                    <span>Costo est: {settings.currencySymbol} {t.estimatedCost}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Concierge & Packages Alert */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-slate-900 text-sm">Portería & Encomiendas</h3>
              <button
                onClick={() => onNavigate('concierge')}
                className="text-xs font-semibold text-amber-600 hover:text-amber-700"
              >
                Bitácora →
              </button>
            </div>
            <p className="text-xs text-slate-500 mb-2">
              Paquetes pendientes por retirar en conserjería:
            </p>
            {pendingPackages.length > 0 ? (
              <div className="space-y-2">
                {pendingPackages.map(pkg => (
                  <div key={pkg.id} className="flex items-center justify-between p-2 rounded-lg bg-slate-50 text-xs">
                    <div>
                      <p className="font-bold text-slate-800">Unidad {pkg.unitNumber} · {pkg.recipientName}</p>
                      <p className="text-[11px] text-slate-500">{pkg.courier} ({pkg.trackingNumber})</p>
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-800">
                      En Portería
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-400 italic">No hay encomiendas pendientes en portería.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
