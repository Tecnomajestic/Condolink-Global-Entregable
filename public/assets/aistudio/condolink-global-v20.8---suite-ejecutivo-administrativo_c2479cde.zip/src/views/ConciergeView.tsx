import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import {
  ShieldCheck,
  Package,
  UserCheck,
  Plus,
  Clock,
  Car,
  CheckCircle2,
  X,
  Truck,
  LogOut,
  Search
} from 'lucide-react';
import { VisitorLog, PackageLog } from '../types/index.ts';

export const ConciergeView: React.FC = () => {
  const {
    visitors,
    packages,
    units,
    condominiums,
    selectedCondoId,
    logVisitor,
    checkoutVisitor,
    logPackage,
    deliverPackage
  } = useApp();

  const [activeTab, setActiveTab] = useState<'visitors' | 'packages'>('visitors');

  // Visitor Form
  const [isVisitorModalOpen, setIsVisitorModalOpen] = useState(false);
  const [visitorName, setVisitorName] = useState('');
  const [visitorId, setVisitorId] = useState('');
  const [unitVisited, setUnitVisited] = useState('101');
  const [vehiclePlate, setVehiclePlate] = useState('');
  const [visitorType, setVisitorType] = useState<VisitorLog['visitorType']>('Visita');
  const [authorizedBy, setAuthorizedBy] = useState('Residente vía Citófono');

  // Package Form
  const [isPackageModalOpen, setIsPackageModalOpen] = useState(false);
  const [pkgUnit, setPkgUnit] = useState('101');
  const [recipientName, setRecipientName] = useState('');
  const [courier, setCourier] = useState<PackageLog['courier']>('MercadoLibre');
  const [trackingNumber, setTrackingNumber] = useState('');
  const [description, setDescription] = useState('Caja mediana sellada');

  // Deliver modal
  const [deliveringPkgId, setDeliveringPkgId] = useState<string | null>(null);
  const [receiverPerson, setReceiverPerson] = useState('');

  const filteredVisitors = visitors.filter(v => {
    if (selectedCondoId !== 'all' && v.condoId !== selectedCondoId) return false;
    return true;
  });

  const filteredPackages = packages.filter(p => {
    if (selectedCondoId !== 'all' && p.condoId !== selectedCondoId) return false;
    return true;
  });

  const handleVisitorSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!visitorName) return;

    logVisitor({
      condoId: selectedCondoId === 'all' ? condominiums[0]?.id : selectedCondoId,
      visitorName,
      visitorId: visitorId || 'Sin documento',
      unitVisited,
      vehiclePlate,
      visitorType,
      authorizedBy,
      guardOnDuty: 'Conserje de Turno'
    });

    setIsVisitorModalOpen(false);
    setVisitorName('');
    setVisitorId('');
    setVehiclePlate('');
  };

  const handlePackageSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!recipientName) return;

    logPackage({
      condoId: selectedCondoId === 'all' ? condominiums[0]?.id : selectedCondoId,
      unitNumber: pkgUnit,
      recipientName,
      courier,
      trackingNumber: trackingNumber || `TRK-${Math.floor(100000 + Math.random() * 900000)}`,
      description,
      receivedByGuard: 'Conserje de Turno'
    });

    setIsPackageModalOpen(false);
    setRecipientName('');
    setTrackingNumber('');
  };

  const handleDeliverConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!deliveringPkgId || !receiverPerson) return;
    deliverPackage(deliveringPkgId, receiverPerson);
    setDeliveringPkgId(null);
    setReceiverPerson('');
  };

  return (
    <div className="space-y-5">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">
            Conserjería, Control de Accesos & Paquetería
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Bitácora de seguridad en portería 24/7, control de visitas, delivery y entrega de encomiendas.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {activeTab === 'visitors' ? (
            <button
              onClick={() => setIsVisitorModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 transition-colors shadow-xs"
            >
              <UserCheck className="w-4 h-4" />
              Registrar Visita / Acceso
            </button>
          ) : (
            <button
              onClick={() => setIsPackageModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 transition-colors shadow-xs"
            >
              <Package className="w-4 h-4" />
              Recibir Encomienda
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200">
        <button
          onClick={() => setActiveTab('visitors')}
          className={`pb-3 px-3 text-xs font-semibold transition-all relative ${
            activeTab === 'visitors'
              ? 'text-amber-600 border-b-2 border-amber-500'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          Control de Visitas & Accesos ({filteredVisitors.length})
        </button>
        <button
          onClick={() => setActiveTab('packages')}
          className={`pb-3 px-3 text-xs font-semibold transition-all relative ${
            activeTab === 'packages'
              ? 'text-amber-600 border-b-2 border-amber-500'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          Recepción de Encomiendas & Paquetes ({filteredPackages.length})
        </button>
      </div>

      {/* TAB 1: VISITORS */}
      {activeTab === 'visitors' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase tracking-wider font-semibold text-[11px]">
                  <th className="py-3 px-4">Visitante & RUT/ID</th>
                  <th className="py-3 px-4">Destino / Depto</th>
                  <th className="py-3 px-4">Tipo</th>
                  <th className="py-3 px-4">Vehículo / Placa</th>
                  <th className="py-3 px-4">Hora Ingreso</th>
                  <th className="py-3 px-4">Salida</th>
                  <th className="py-3 px-4">Autorizado por</th>
                  <th className="py-3 px-4 text-center">Acción</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredVisitors.map((vis) => (
                  <tr key={vis.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4">
                      <p className="font-bold text-slate-900">{vis.visitorName}</p>
                      <p className="text-[10px] text-slate-400 font-mono">{vis.visitorId}</p>
                    </td>
                    <td className="py-3 px-4 font-bold text-slate-800">
                      Unidad {vis.unitVisited}
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-[11px] font-medium text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                        {vis.visitorType}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-600">
                      {vis.vehiclePlate || 'Peatonal'}
                    </td>
                    <td className="py-3 px-4 text-slate-600">
                      {vis.entryTimestamp}
                    </td>
                    <td className="py-3 px-4">
                      {vis.exitTimestamp ? (
                        <span className="text-slate-600">{vis.exitTimestamp}</span>
                      ) : (
                        <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded text-[11px]">
                          En el Edificio
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-slate-500 text-[11px]">
                      {vis.authorizedBy}
                    </td>
                    <td className="py-3 px-4 text-center">
                      {!vis.exitTimestamp && (
                        <button
                          onClick={() => checkoutVisitor(vis.id)}
                          className="px-2.5 py-1 text-[11px] font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded transition-colors inline-flex items-center gap-1"
                        >
                          <LogOut className="w-3 h-3" />
                          Marcar Salida
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: PACKAGES */}
      {activeTab === 'packages' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase tracking-wider font-semibold text-[11px]">
                  <th className="py-3 px-4">Unidad & Destinatario</th>
                  <th className="py-3 px-4">Empresa / Courier</th>
                  <th className="py-3 px-4">N° de Seguimiento</th>
                  <th className="py-3 px-4">Descripción del Paquete</th>
                  <th className="py-3 px-4">Fecha Llegada</th>
                  <th className="py-3 px-4 text-center">Estado</th>
                  <th className="py-3 px-4 text-center">Acción</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredPackages.map((pkg) => {
                  const isInDesk = pkg.status === 'En Conserjería';

                  return (
                    <tr key={pkg.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4">
                        <p className="font-bold text-slate-900">Depto {pkg.unitNumber}</p>
                        <p className="text-[11px] text-slate-600">{pkg.recipientName}</p>
                      </td>
                      <td className="py-3 px-4 font-semibold text-slate-800">
                        {pkg.courier}
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-600 text-[11px]">
                        {pkg.trackingNumber}
                      </td>
                      <td className="py-3 px-4 text-slate-600 max-w-xs truncate">
                        {pkg.description}
                      </td>
                      <td className="py-3 px-4 text-slate-500">
                        {pkg.receivedDate}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold ${
                            isInDesk
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {pkg.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        {isInDesk ? (
                          <button
                            onClick={() => {
                              setDeliveringPkgId(pkg.id);
                              setReceiverPerson(pkg.recipientName);
                            }}
                            className="px-2.5 py-1 text-[11px] font-bold rounded bg-emerald-600 hover:bg-emerald-700 text-white transition-colors"
                          >
                            Entregar al Residente
                          </button>
                        ) : (
                          <span className="text-[11px] text-slate-400">
                            Entregado a {pkg.deliveredToPerson} ({pkg.deliveredDate})
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Visitor Modal */}
      {isVisitorModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="relative w-full max-w-md bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden my-6">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
              <div className="flex items-center gap-2">
                <UserCheck className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-base">Registrar Ingreso de Visita / Técnico</h3>
              </div>
              <button
                onClick={() => setIsVisitorModalOpen(false)}
                className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleVisitorSubmit} className="p-6 space-y-4 text-sm">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                  Nombre Completo Visitante
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ej. Rodrigo Santibáñez"
                  value={visitorName}
                  onChange={(e) => setVisitorName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    RUT / DNI
                  </label>
                  <input
                    type="text"
                    placeholder="17.209.441-3"
                    value={visitorId}
                    onChange={(e) => setVisitorId(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Unidad / Depto Destino
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="101"
                    value={unitVisited}
                    onChange={(e) => setUnitVisited(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Tipo de Ingreso
                  </label>
                  <select
                    value={visitorType}
                    onChange={(e) => setVisitorType(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs"
                  >
                    <option value="Visita">Visita Familiar/Amigo</option>
                    <option value="Delivery/Repartidor">Delivery / Repartidor</option>
                    <option value="Contratista/Técnico">Contratista / Técnico</option>
                    <option value="Mudanza">Mudanza</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Placa Patente (Opcional)
                  </label>
                  <input
                    type="text"
                    placeholder="LX-88-21"
                    value={vehiclePlate}
                    onChange={(e) => setVehiclePlate(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs font-mono uppercase"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                  Medio de Autorización
                </label>
                <input
                  type="text"
                  value={authorizedBy}
                  onChange={(e) => setAuthorizedBy(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs"
                />
              </div>

              <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsVisitorModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-slate-950 bg-amber-500 hover:bg-amber-600 rounded-lg shadow-xs transition-colors"
                >
                  Registrar Entrada
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Package Modal */}
      {isPackageModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="relative w-full max-w-md bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden my-6">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white">
              <div className="flex items-center gap-2">
                <Package className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-base">Recepcionar Encomienda en Portería</h3>
              </div>
              <button
                onClick={() => setIsPackageModalOpen(false)}
                className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handlePackageSubmit} className="p-6 space-y-4 text-sm">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Unidad / Depto
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="101, 201..."
                    value={pkgUnit}
                    onChange={(e) => setPkgUnit(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                    Empresa Courier
                  </label>
                  <select
                    value={courier}
                    onChange={(e) => setCourier(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs"
                  >
                    <option value="MercadoLibre">MercadoLibre</option>
                    <option value="Amazon">Amazon</option>
                    <option value="Chilexpress">Chilexpress</option>
                    <option value="Correos">Correos de Chile / Nacional</option>
                    <option value="FedEx/DHL">FedEx / DHL</option>
                    <option value="Otro">Otro Courier</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                  Nombre del Destinatario
                </label>
                <input
                  type="text"
                  required
                  placeholder="Nombre de quien recibe"
                  value={recipientName}
                  onChange={(e) => setRecipientName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                  N° de Guía / Tracking (Opcional)
                </label>
                <input
                  type="text"
                  placeholder="Ej. TBA-98124018"
                  value={trackingNumber}
                  onChange={(e) => setTrackingNumber(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 mb-1">
                  Descripción del Paquete
                </label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Caja mediana, sobre sellado, bolsa..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs"
                />
              </div>

              <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsPackageModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-slate-950 bg-amber-500 hover:bg-amber-600 rounded-lg shadow-xs transition-colors"
                >
                  Guardar en Portería
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Deliver Confirmation Modal */}
      {deliveringPkgId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="relative w-full max-w-sm bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden my-6">
            <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h4 className="font-bold text-sm">Entregar Encomienda al Residente</h4>
              <button onClick={() => setDeliveringPkgId(null)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleDeliverConfirm} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Persona que Retira / Firma
                </label>
                <input
                  type="text"
                  required
                  value={receiverPerson}
                  onChange={(e) => setReceiverPerson(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-semibold"
                />
              </div>
              <div className="p-3 bg-slate-50 border border-slate-200 rounded text-slate-500">
                Al confirmar, se registrará la hora exacta de entrega y se notificará en la bitácora de auditoría.
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setDeliveringPkgId(null)}
                  className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded"
                >
                  Confirmar Entrega
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
