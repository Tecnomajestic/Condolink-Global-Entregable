import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import {
  DollarSign,
  Receipt,
  CreditCard,
  Building,
  CheckCircle2,
  Calendar,
  Download,
  Plus,
  Landmark,
  FileSpreadsheet,
  AlertCircle,
  FileCheck,
  Check
} from 'lucide-react';
import { ExpenseRecord, MaintenanceFeeInvoice } from '../types/index.ts';

interface FinanceViewProps {
  onOpenPaymentModal: () => void;
  onOpenExpenseModal: () => void;
  onOpenInvoiceModal: () => void;
}

export const FinanceView: React.FC<FinanceViewProps> = ({
  onOpenPaymentModal,
  onOpenExpenseModal,
  onOpenInvoiceModal
}) => {
  const {
    invoices,
    payments,
    expenses,
    selectedCondoId,
    condominiums,
    markExpensePaid,
    setActiveReceipt,
    settings
  } = useApp();

  const [activeTab, setActiveTab] = useState<'invoices' | 'expenses' | 'bank' | 'pl'>('invoices');
  const [invoiceFilter, setInvoiceFilter] = useState<'all' | 'Pagado' | 'Pendiente' | 'Vencido'>('all');

  const filteredInvoices = invoices.filter(inv => {
    if (selectedCondoId !== 'all' && inv.condoId !== selectedCondoId) return false;
    if (invoiceFilter !== 'all' && inv.status !== invoiceFilter) return false;
    return true;
  });

  const filteredExpenses = expenses.filter(exp => {
    if (selectedCondoId !== 'all' && exp.condoId !== selectedCondoId) return false;
    return true;
  });

  const filteredPayments = payments.filter(pay => {
    if (selectedCondoId !== 'all' && pay.condoId !== selectedCondoId) return false;
    return true;
  });

  const totalInvoiced = filteredInvoices.reduce((a, b) => a + b.totalAmount, 0);
  const totalReceived = filteredPayments.reduce((a, b) => a + b.amount, 0);
  const totalExpenses = filteredExpenses.reduce((a, b) => a + b.amount, 0);
  const netResult = totalReceived - totalExpenses;

  // CSV Exporter
  const exportInvoicesCSV = () => {
    const headers = ['Nro Factura', 'Unidad', 'Copropietario', 'Periodo', 'Total', 'Pagado', 'Saldo', 'Estado'];
    const rows = filteredInvoices.map(i => [
      i.invoiceNumber,
      i.unitNumber,
      `"${i.residentName}"`,
      `"${i.period}"`,
      i.totalAmount.toFixed(2),
      i.amountPaid.toFixed(2),
      i.balanceRemaining.toFixed(2),
      i.status
    ]);
    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Condolink_Gastos_Comunes_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-5">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">
            Suite Contable, Financiera & Cobranzas V20.8
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Emisión de alícuotas, control de recaudación, cuentas por pagar y conciliación bancaria.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenInvoiceModal}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 transition-colors"
          >
            <Calendar className="w-3.5 h-3.5" />
            Emisión Masiva
          </button>
          <button
            onClick={onOpenPaymentModal}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 transition-colors shadow-xs"
          >
            <CreditCard className="w-4 h-4" />
            Registrar Cobranza
          </button>
        </div>
      </div>

      {/* Tabs Bar */}
      <div className="flex items-center gap-2 border-b border-slate-200">
        <button
          onClick={() => setActiveTab('invoices')}
          className={`pb-3 px-3 text-xs font-semibold transition-all relative ${
            activeTab === 'invoices'
              ? 'text-amber-600 border-b-2 border-amber-500'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          Gastos Comunes & Boletas ({filteredInvoices.length})
        </button>
        <button
          onClick={() => setActiveTab('expenses')}
          className={`pb-3 px-3 text-xs font-semibold transition-all relative ${
            activeTab === 'expenses'
              ? 'text-amber-600 border-b-2 border-amber-500'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          Cuentas por Pagar / Egresos ({filteredExpenses.length})
        </button>
        <button
          onClick={() => setActiveTab('bank')}
          className={`pb-3 px-3 text-xs font-semibold transition-all relative ${
            activeTab === 'bank'
              ? 'text-amber-600 border-b-2 border-amber-500'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          Conciliación Bancaria
        </button>
        <button
          onClick={() => setActiveTab('pl')}
          className={`pb-3 px-3 text-xs font-semibold transition-all relative ${
            activeTab === 'pl'
              ? 'text-amber-600 border-b-2 border-amber-500'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          Estado de Resultados (P&L)
        </button>
      </div>

      {/* TAB 1: INVOICES / GASTOS COMUNES */}
      {activeTab === 'invoices' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-500">Filtrar estado:</span>
              <div className="flex items-center p-1 bg-slate-100 rounded-lg text-xs">
                {(['all', 'Pagado', 'Pendiente', 'Vencido'] as const).map(f => (
                  <button
                    key={f}
                    onClick={() => setInvoiceFilter(f)}
                    className={`px-3 py-1 rounded-md transition-colors ${
                      invoiceFilter === f ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {f === 'all' ? 'Todos' : f}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={exportInvoicesCSV}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              Exportar a CSV
            </button>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase tracking-wider font-semibold text-[11px]">
                    <th className="py-3 px-4">N° Boleta / Emisión</th>
                    <th className="py-3 px-4">Unidad & Copropietario</th>
                    <th className="py-3 px-4">Período</th>
                    <th className="py-3 px-4 text-right">Cuota Base</th>
                    <th className="py-3 px-4 text-right">Fondo Reserva (5%)</th>
                    <th className="py-3 px-4 text-right">Total Facturado</th>
                    <th className="py-3 px-4 text-center">Estado</th>
                    <th className="py-3 px-4 text-center">Acción</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredInvoices.map((inv) => (
                    <tr key={inv.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-slate-900">
                        {inv.invoiceNumber}
                      </td>
                      <td className="py-3 px-4">
                        <p className="font-bold text-slate-900">Depto {inv.unitNumber}</p>
                        <p className="text-[11px] text-slate-500 truncate max-w-xs">{inv.residentName}</p>
                      </td>
                      <td className="py-3 px-4 text-slate-600 font-medium">
                        {inv.period}
                        <span className="block text-[10px] text-slate-400">Vence: {inv.dueDate}</span>
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-slate-700">
                        {settings.currencySymbol} {inv.baseCommonFee.toFixed(2)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-slate-700">
                        {settings.currencySymbol} {inv.reserveFundAmount.toFixed(2)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 text-sm">
                        {settings.currencySymbol} {inv.totalAmount.toFixed(2)}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold ${
                            inv.status === 'Pagado'
                              ? 'bg-emerald-100 text-emerald-800'
                              : inv.status === 'Vencido'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {inv.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        {inv.status !== 'Pagado' ? (
                          <button
                            onClick={onOpenPaymentModal}
                            className="px-2.5 py-1 text-[11px] font-bold rounded bg-amber-500 hover:bg-amber-600 text-slate-950 transition-colors"
                          >
                            Pagar
                          </button>
                        ) : (
                          <span className="text-[11px] text-emerald-600 font-medium flex items-center justify-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Al día
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-600">
              <span>Total emitido en pantalla: <strong>{filteredInvoices.length} boletas</strong></span>
              <span className="font-mono text-sm">
                Monto Global: <strong>{settings.currencySymbol} {totalInvoiced.toLocaleString('es-CL', { minimumFractionDigits: 2 })}</strong>
              </span>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: EXPENSES / CUENTAS POR PAGAR */}
      {activeTab === 'expenses' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Registro de Proveedores & Egresos Comunes</h3>
              <p className="text-xs text-slate-500">Mantenimiento, servicios básicos, conserjería y seguros</p>
            </div>
            <button
              onClick={onOpenExpenseModal}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 transition-colors"
            >
              <Plus className="w-4 h-4" />
              Nuevo Egreso
            </button>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase tracking-wider font-semibold text-[11px]">
                    <th className="py-3 px-4">Egreso / Factura</th>
                    <th className="py-3 px-4">Proveedor</th>
                    <th className="py-3 px-4">Categoría</th>
                    <th className="py-3 px-4">Descripción</th>
                    <th className="py-3 px-4">Vencimiento</th>
                    <th className="py-3 px-4 text-right">Monto</th>
                    <th className="py-3 px-4 text-center">Estado</th>
                    <th className="py-3 px-4 text-center">Acción</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredExpenses.map((exp) => (
                    <tr key={exp.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4">
                        <p className="font-mono font-bold text-slate-900">{exp.expenseNumber}</p>
                        <p className="text-[10px] text-slate-400">{exp.invoiceNumber}</p>
                      </td>
                      <td className="py-3 px-4">
                        <p className="font-semibold text-slate-900">{exp.supplier}</p>
                        <p className="text-[10px] text-slate-400 font-mono">{exp.supplierTaxId}</p>
                      </td>
                      <td className="py-3 px-4">
                        <span className="text-[11px] font-medium text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                          {exp.category}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-600 max-w-xs truncate">
                        {exp.description}
                      </td>
                      <td className="py-3 px-4 text-slate-600">
                        {exp.dueDate}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 text-sm">
                        {settings.currencySymbol} {exp.amount.toFixed(2)}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold ${
                            exp.status === 'Pagado'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {exp.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        {exp.status !== 'Pagado' ? (
                          <button
                            onClick={() => markExpensePaid(exp.id, 'Transferencia Bancaria')}
                            className="px-2.5 py-1 text-[11px] font-bold rounded bg-emerald-600 hover:bg-emerald-700 text-white transition-colors"
                          >
                            Pagar
                          </button>
                        ) : (
                          <span className="text-[11px] text-emerald-600 font-medium">
                            Pagado ({exp.paymentDate})
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-600">
              <span>Total egresos registrados: <strong>{filteredExpenses.length} facturas</strong></span>
              <span className="font-mono text-sm">
                Total a Pagar: <strong>{settings.currencySymbol} {totalExpenses.toLocaleString('es-CL', { minimumFractionDigits: 2 })}</strong>
              </span>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: BANK RECONCILIATION */}
      {activeTab === 'bank' && (
        <div className="space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {condominiums.map(c => (
              <div key={c.id} className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                <div className="flex items-center gap-2 mb-2">
                  <Landmark className="w-5 h-5 text-amber-500" />
                  <h4 className="font-bold text-slate-900 text-sm">{c.bankName}</h4>
                </div>
                <p className="text-xs text-slate-500 font-mono">{c.bankAccount}</p>
                <p className="text-xs text-slate-600 font-medium mt-1">{c.name}</p>
                <div className="mt-4 pt-3 border-t border-slate-100 flex justify-between items-baseline">
                  <span className="text-xs text-slate-400">Saldo Conciliado:</span>
                  <span className="text-lg font-black text-slate-900 font-mono">
                    {settings.currencySymbol} {(Math.random() * 5000 + 12000).toFixed(2)}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
            <h3 className="font-bold text-slate-900 text-sm mb-1">
              Libro Mayor de Conciliación Bancaria Automática
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Cruce entre transferencias bancarias de residentes y facturas debitadas por proveedores.
            </p>

            <div className="divide-y divide-slate-100 text-xs">
              {filteredPayments.map(pay => (
                <div key={pay.id} className="py-2.5 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-slate-900">ABONO: {pay.payerName} (Depto {pay.unitNumber})</span>
                    <span className="text-slate-400 block text-[11px]">{pay.paymentDate} · Ref: {pay.referenceNumber}</span>
                  </div>
                  <span className="font-mono font-bold text-emerald-600 text-sm">
                    +{settings.currencySymbol} {pay.amount.toFixed(2)}
                  </span>
                </div>
              ))}
              {filteredExpenses.filter(e => e.status === 'Pagado').map(exp => (
                <div key={exp.id} className="py-2.5 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-slate-900">CARGO: {exp.supplier}</span>
                    <span className="text-slate-400 block text-[11px]">{exp.paymentDate} · Factura: {exp.invoiceNumber}</span>
                  </div>
                  <span className="font-mono font-bold text-rose-600 text-sm">
                    -{settings.currencySymbol} {exp.amount.toFixed(2)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: P&L / ESTADO DE RESULTADOS */}
      {activeTab === 'pl' && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs max-w-3xl mx-auto">
          <div className="text-center pb-6 border-b border-slate-200">
            <h2 className="text-base font-bold text-slate-900 uppercase tracking-wider">
              Estado de Resultados Operacional (P&L)
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Condolink Global V20.8 · Ejercicio Fiscal Vigente
            </p>
          </div>

          <div className="py-6 space-y-4 text-xs">
            {/* Ingresos */}
            <div>
              <div className="flex justify-between items-center text-sm font-bold text-slate-900 pb-2 border-b border-slate-200">
                <span>1. INGRESOS OPERACIONALES</span>
                <span className="font-mono text-emerald-600">
                  +{settings.currencySymbol} {totalReceived.toFixed(2)}
                </span>
              </div>
              <div className="pl-4 py-2 space-y-1.5 text-slate-600">
                <div className="flex justify-between">
                  <span>Recaudación por Gastos Comunes Ordinarios</span>
                  <span className="font-mono">{settings.currencySymbol} {(totalReceived * 0.95).toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Aportes Fondo de Reserva Legal (5%)</span>
                  <span className="font-mono">{settings.currencySymbol} {(totalReceived * 0.05).toFixed(2)}</span>
                </div>
              </div>
            </div>

            {/* Egresos */}
            <div>
              <div className="flex justify-between items-center text-sm font-bold text-slate-900 pb-2 border-b border-slate-200">
                <span>2. EGRESOS OPERACIONALES & PROVEEDORES</span>
                <span className="font-mono text-rose-600">
                  -{settings.currencySymbol} {totalExpenses.toFixed(2)}
                </span>
              </div>
              <div className="pl-4 py-2 space-y-1.5 text-slate-600">
                {filteredExpenses.map(e => (
                  <div key={e.id} className="flex justify-between">
                    <span>{e.category} ({e.supplier})</span>
                    <span className="font-mono">{settings.currencySymbol} {e.amount.toFixed(2)}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Net Result */}
            <div className="pt-4 border-t-2 border-slate-900 flex justify-between items-center text-base font-black">
              <span className="text-slate-900">RESULTADO NETO / SUPERÁVIT DEL PERÍODO</span>
              <span className={`font-mono text-lg ${netResult >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                {settings.currencySymbol} {netResult.toFixed(2)}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
