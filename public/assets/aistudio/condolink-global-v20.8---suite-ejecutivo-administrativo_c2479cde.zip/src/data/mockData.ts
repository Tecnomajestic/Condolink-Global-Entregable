import {
  Condominium,
  Unit,
  Resident,
  MaintenanceFeeInvoice,
  PaymentRecord,
  ExpenseRecord,
  MaintenanceTicket,
  Amenity,
  AmenityReservation,
  VisitorLog,
  PackageLog,
  AssemblyMeeting,
  OfficialNotice,
  AppSettings
} from '../types/index.ts';

export const initialCondominiums: Condominium[] = [
  {
    id: 'condo-1',
    name: 'Condominio Residencial Mirador del Sol',
    code: 'MDS-01',
    address: 'Av. Las Condes 10450',
    city: 'Santiago, Región Metropolitana',
    totalUnits: 48,
    administrator: 'Condolink Global Ejecutivo - Roberto Valenzuela',
    adminEmail: 'condolinkglobal@gmail.com',
    taxId: 'CL-76.491.204-K',
    bankName: 'Banco Santander Corporate',
    bankAccount: 'Cta. Corriente #004-98214-02',
    currency: 'USD',
    reserveFundPercentage: 5,
    defaultLateFeePercentage: 2.5
  },
  {
    id: 'condo-2',
    name: 'Torres del Parque Ejecutivo & Suites',
    code: 'TDP-02',
    address: 'Paseo de la Reforma 2400',
    city: 'Distrito Financiero Central',
    totalUnits: 64,
    administrator: 'Condolink Global Ejecutivo - Marcela Gómez',
    adminEmail: 'condolinkglobal@gmail.com',
    taxId: 'CL-77.102.399-4',
    bankName: 'Banco BCI Premier',
    bankAccount: 'Cta. Corriente #110-38491-09',
    currency: 'USD',
    reserveFundPercentage: 6,
    defaultLateFeePercentage: 2.0
  },
  {
    id: 'condo-3',
    name: 'Edificio Bahía Platinum Marina',
    code: 'BPM-03',
    address: 'Costanera Norte 850',
    city: 'Sector Marina Premium',
    totalUnits: 32,
    administrator: 'Condolink Global Ejecutivo - Carlos Mendez',
    adminEmail: 'condolinkglobal@gmail.com',
    taxId: 'CL-76.883.120-1',
    bankName: 'Banco de Chile Corporativo',
    bankAccount: 'Cta. Corriente #001-44582-77',
    currency: 'USD',
    reserveFundPercentage: 5,
    defaultLateFeePercentage: 3.0
  }
];

export const initialUnits: Unit[] = [
  {
    id: 'unit-101',
    condoId: 'condo-1',
    unitNumber: '101',
    towerOrBlock: 'Torre A',
    floor: 1,
    type: 'Apartamento',
    areaSqMeters: 85,
    aliquotPercentage: 2.10,
    parkingSpots: 'E-04',
    storageUnit: 'B-12',
    occupancyStatus: 'Propietario Residente',
    currentBalance: 0,
    paymentStatus: 'Solvente',
    primaryResidentName: 'Alejandro Morales Rivas',
    primaryResidentEmail: 'amorales@gmail.com',
    primaryResidentPhone: '+56 9 8452 1190',
    unpaidMonthsCount: 0
  },
  {
    id: 'unit-102',
    condoId: 'condo-1',
    unitNumber: '102',
    towerOrBlock: 'Torre A',
    floor: 1,
    type: 'Apartamento',
    areaSqMeters: 92,
    aliquotPercentage: 2.25,
    parkingSpots: 'E-05',
    storageUnit: 'B-14',
    occupancyStatus: 'Arrendado',
    currentBalance: 245.50,
    paymentStatus: 'En Mora',
    primaryResidentName: 'Valeria Castro Peña',
    primaryResidentEmail: 'vcastro.inquilino@outlook.com',
    primaryResidentPhone: '+56 9 7311 9920',
    unpaidMonthsCount: 1
  },
  {
    id: 'unit-201',
    condoId: 'condo-1',
    unitNumber: '201',
    towerOrBlock: 'Torre A',
    floor: 2,
    type: 'Apartamento',
    areaSqMeters: 110,
    aliquotPercentage: 2.65,
    parkingSpots: 'E-12, E-13',
    storageUnit: 'B-21',
    occupancyStatus: 'Propietario Residente',
    currentBalance: 0,
    paymentStatus: 'Solvente',
    primaryResidentName: 'Dra. Carmen Gloria Fuentes',
    primaryResidentEmail: 'cgfuentes.med@gmail.com',
    primaryResidentPhone: '+56 9 9123 4455',
    unpaidMonthsCount: 0
  },
  {
    id: 'unit-202',
    condoId: 'condo-1',
    unitNumber: '202',
    towerOrBlock: 'Torre A',
    floor: 2,
    type: 'Apartamento',
    areaSqMeters: 88,
    aliquotPercentage: 2.15,
    parkingSpots: 'E-14',
    storageUnit: 'B-22',
    occupancyStatus: 'Arrendado',
    currentBalance: 512.00,
    paymentStatus: 'En Mora',
    primaryResidentName: 'Jorge Ignacio Villalobos',
    primaryResidentEmail: 'jvillalobos@corporacion.cl',
    primaryResidentPhone: '+56 9 6442 8110',
    unpaidMonthsCount: 2
  },
  {
    id: 'unit-301',
    condoId: 'condo-1',
    unitNumber: '301',
    towerOrBlock: 'Torre B',
    floor: 3,
    type: 'Apartamento',
    areaSqMeters: 105,
    aliquotPercentage: 2.50,
    parkingSpots: 'E-20',
    storageUnit: 'B-30',
    occupancyStatus: 'Propietario Residente',
    currentBalance: -50.00,
    paymentStatus: 'Con Saldo a Favor',
    primaryResidentName: 'Ing. Fernando Soto Bravo',
    primaryResidentEmail: 'fsoto.ing@yahoo.com',
    primaryResidentPhone: '+56 9 5501 2284',
    unpaidMonthsCount: 0
  },
  {
    id: 'unit-PH1',
    condoId: 'condo-1',
    unitNumber: 'PH-01',
    towerOrBlock: 'Torre B',
    floor: 8,
    type: 'Penthouse',
    areaSqMeters: 185,
    aliquotPercentage: 4.40,
    parkingSpots: 'E-01, E-02, E-03',
    storageUnit: 'B-01',
    occupancyStatus: 'Propietario Residente',
    currentBalance: 0,
    paymentStatus: 'Solvente',
    primaryResidentName: 'Mariana Silva Echeverría',
    primaryResidentEmail: 'msilva.design@gmail.com',
    primaryResidentPhone: '+56 9 4410 7799',
    unpaidMonthsCount: 0
  },
  {
    id: 'unit-tdp-101',
    condoId: 'condo-2',
    unitNumber: 'Torre 1 - 402',
    towerOrBlock: 'Torre 1',
    floor: 4,
    type: 'Apartamento',
    areaSqMeters: 95,
    aliquotPercentage: 2.30,
    parkingSpots: 'P-15',
    storageUnit: 'Bodega 08',
    occupancyStatus: 'Propietario Residente',
    currentBalance: 0,
    paymentStatus: 'Solvente',
    primaryResidentName: 'Gonzalo Navarro C.',
    primaryResidentEmail: 'gnavarro@tdp.com',
    primaryResidentPhone: '+56 9 8812 3344',
    unpaidMonthsCount: 0
  },
  {
    id: 'unit-bpm-201',
    condoId: 'condo-3',
    unitNumber: 'Suite 201 Marina',
    towerOrBlock: 'Ala Norte',
    floor: 2,
    type: 'Penthouse',
    areaSqMeters: 140,
    aliquotPercentage: 3.12,
    parkingSpots: 'M-02, M-03',
    storageUnit: 'BM-04',
    occupancyStatus: 'Propietario Residente',
    currentBalance: 0,
    paymentStatus: 'Solvente',
    primaryResidentName: 'Esteban Larraín Matte',
    primaryResidentEmail: 'elarraim@inversiones.com',
    primaryResidentPhone: '+56 9 7722 0011',
    unpaidMonthsCount: 0
  }
];

export const initialResidents: Resident[] = [
  {
    id: 'res-1',
    unitId: 'unit-101',
    condoId: 'condo-1',
    name: 'Alejandro Morales Rivas',
    rutOrId: '15.420.918-2',
    email: 'amorales@gmail.com',
    phone: '+56 9 8452 1190',
    isOwner: true,
    occupantType: 'Propietario',
    vehicles: ['JP-94-22 (Audi A4 Negro)'],
    pets: ['Golden Retriever ("Max")'],
    accessCards: ['TAG-99021', 'TAG-99022']
  },
  {
    id: 'res-2',
    unitId: 'unit-102',
    condoId: 'condo-1',
    name: 'Valeria Castro Peña',
    rutOrId: '18.112.504-9',
    email: 'vcastro.inquilino@outlook.com',
    phone: '+56 9 7311 9920',
    isOwner: false,
    occupantType: 'Inquilino',
    vehicles: ['KL-44-12 (Toyota Yaris Blanco)'],
    pets: ['Gato Siamés ("Luna")'],
    accessCards: ['TAG-99105']
  },
  {
    id: 'res-3',
    unitId: 'unit-201',
    condoId: 'condo-1',
    name: 'Dra. Carmen Gloria Fuentes',
    rutOrId: '12.871.440-6',
    email: 'cgfuentes.med@gmail.com',
    phone: '+56 9 9123 4455',
    isOwner: true,
    occupantType: 'Propietario',
    vehicles: ['PT-10-88 (Volvo XC60 Gris)', 'RX-77-33 (BMW Serie 1)'],
    pets: [],
    accessCards: ['TAG-98441', 'TAG-98442', 'TAG-98443']
  }
];

export const initialInvoices: MaintenanceFeeInvoice[] = [
  {
    id: 'inv-2026-11-101',
    invoiceNumber: 'GC-2026-11-001',
    condoId: 'condo-1',
    unitId: 'unit-101',
    unitNumber: '101',
    residentName: 'Alejandro Morales Rivas',
    period: 'Noviembre 2026',
    issueDate: '2026-11-01',
    dueDate: '2026-11-15',
    baseCommonFee: 168.00,
    reserveFundAmount: 8.40,
    waterOrUtilityAmount: 22.50,
    parkingOrExtraFee: 15.00,
    penaltiesOrLateFee: 0,
    totalAmount: 213.90,
    amountPaid: 213.90,
    balanceRemaining: 0,
    status: 'Pagado'
  },
  {
    id: 'inv-2026-11-102',
    invoiceNumber: 'GC-2026-11-002',
    condoId: 'condo-1',
    unitId: 'unit-102',
    unitNumber: '102',
    residentName: 'Valeria Castro Peña',
    period: 'Noviembre 2026',
    issueDate: '2026-11-01',
    dueDate: '2026-11-15',
    baseCommonFee: 180.00,
    reserveFundAmount: 9.00,
    waterOrUtilityAmount: 41.50,
    parkingOrExtraFee: 15.00,
    penaltiesOrLateFee: 0,
    totalAmount: 245.50,
    amountPaid: 0,
    balanceRemaining: 245.50,
    status: 'Pendiente'
  },
  {
    id: 'inv-2026-11-201',
    invoiceNumber: 'GC-2026-11-003',
    condoId: 'condo-1',
    unitId: 'unit-201',
    unitNumber: '201',
    residentName: 'Dra. Carmen Gloria Fuentes',
    period: 'Noviembre 2026',
    issueDate: '2026-11-01',
    dueDate: '2026-11-15',
    baseCommonFee: 212.00,
    reserveFundAmount: 10.60,
    waterOrUtilityAmount: 34.00,
    parkingOrExtraFee: 30.00,
    penaltiesOrLateFee: 0,
    totalAmount: 286.60,
    amountPaid: 286.60,
    balanceRemaining: 0,
    status: 'Pagado'
  },
  {
    id: 'inv-2026-11-202',
    invoiceNumber: 'GC-2026-11-004',
    condoId: 'condo-1',
    unitId: 'unit-202',
    unitNumber: '202',
    residentName: 'Jorge Ignacio Villalobos',
    period: 'Noviembre 2026',
    issueDate: '2026-11-01',
    dueDate: '2026-11-15',
    baseCommonFee: 172.00,
    reserveFundAmount: 8.60,
    waterOrUtilityAmount: 45.00,
    parkingOrExtraFee: 15.00,
    penaltiesOrLateFee: 26.40,
    totalAmount: 267.00,
    amountPaid: 0,
    balanceRemaining: 267.00,
    status: 'Vencido'
  },
  {
    id: 'inv-2026-11-PH1',
    invoiceNumber: 'GC-2026-11-005',
    condoId: 'condo-1',
    unitId: 'unit-PH1',
    unitNumber: 'PH-01',
    residentName: 'Mariana Silva Echeverría',
    period: 'Noviembre 2026',
    issueDate: '2026-11-01',
    dueDate: '2026-11-15',
    baseCommonFee: 352.00,
    reserveFundAmount: 17.60,
    waterOrUtilityAmount: 58.20,
    parkingOrExtraFee: 45.00,
    penaltiesOrLateFee: 0,
    totalAmount: 472.80,
    amountPaid: 472.80,
    balanceRemaining: 0,
    status: 'Pagado'
  }
];

export const initialPayments: PaymentRecord[] = [
  {
    id: 'pay-001',
    receiptNumber: 'REC-2026-10492',
    condoId: 'condo-1',
    unitId: 'unit-101',
    unitNumber: '101',
    payerName: 'Alejandro Morales Rivas',
    paymentDate: '2026-11-01 09:14',
    amount: 213.90,
    paymentMethod: 'Transferencia Bancaria',
    referenceNumber: 'TX-BCO-9482014',
    destinationAccount: 'Cta. Corriente #004-98214-02 (Banco Santander)',
    concept: 'Pago Gasto Común Noviembre 2026',
    verifiedBy: 'Condolink Auto-Conciliación V20.8'
  },
  {
    id: 'pay-002',
    receiptNumber: 'REC-2026-10493',
    condoId: 'condo-1',
    unitId: 'unit-201',
    unitNumber: '201',
    payerName: 'Dra. Carmen Gloria Fuentes',
    paymentDate: '2026-11-01 10:20',
    amount: 286.60,
    paymentMethod: 'Transferencia Bancaria',
    referenceNumber: 'TX-CHILE-009124',
    destinationAccount: 'Cta. Corriente #004-98214-02 (Banco Santander)',
    concept: 'Alícuota Ordinaria Noviembre 2026',
    verifiedBy: 'Condolink Auto-Conciliación V20.8'
  },
  {
    id: 'pay-003',
    receiptNumber: 'REC-2026-10494',
    condoId: 'condo-1',
    unitId: 'unit-PH1',
    unitNumber: 'PH-01',
    payerName: 'Mariana Silva Echeverría',
    paymentDate: '2026-11-01 11:45',
    amount: 472.80,
    paymentMethod: 'Tarjeta de Débito/Crédito',
    referenceNumber: 'TB-POS-554199',
    destinationAccount: 'Cta. Corriente #004-98214-02 (Banco Santander)',
    concept: 'Gasto Común Noviembre 2026 + 3 Estacionamientos',
    verifiedBy: 'Pasarela Integrada Condolink'
  }
];

export const initialExpenses: ExpenseRecord[] = [
  {
    id: 'exp-01',
    condoId: 'condo-1',
    expenseNumber: 'EGR-2026-1101',
    category: 'Seguridad y Vigilancia',
    supplier: 'Securitas Chile & Vigilancia Integral Ltda.',
    supplierTaxId: 'CL-76.331.002-3',
    invoiceNumber: 'FAC-99120',
    description: 'Servicio de Conserjería 24/7 y Monitoreo CCTV 4 turnos',
    issueDate: '2026-10-30',
    dueDate: '2026-11-08',
    paymentDate: '2026-11-01',
    amount: 2850.00,
    status: 'Pagado',
    paymentMethod: 'Transferencia Bancaria'
  },
  {
    id: 'exp-02',
    condoId: 'condo-1',
    expenseNumber: 'EGR-2026-1102',
    category: 'Servicios Básicos (Luz/Agua)',
    supplier: 'Enel Distribución Eléctrica Central',
    supplierTaxId: 'CL-96.800.000-1',
    invoiceNumber: 'ELEC-449102',
    description: 'Suministro eléctrico áreas comunes, ascensores e iluminación perimetral',
    issueDate: '2026-10-28',
    dueDate: '2026-11-12',
    amount: 1420.50,
    status: 'Pendiente'
  },
  {
    id: 'exp-03',
    condoId: 'condo-1',
    expenseNumber: 'EGR-2026-1103',
    category: 'Mantenimiento y Reparaciones',
    supplier: 'Schindler Elevadores S.A.',
    supplierTaxId: 'CL-88.421.300-8',
    invoiceNumber: 'MANT-004128',
    description: 'Mantenimiento preventivo mensual 4 ascensores con certificación Minvu',
    issueDate: '2026-10-25',
    dueDate: '2026-11-10',
    paymentDate: '2026-10-31',
    amount: 890.00,
    status: 'Pagado',
    paymentMethod: 'Transferencia Bancaria'
  },
  {
    id: 'exp-04',
    condoId: 'condo-1',
    expenseNumber: 'EGR-2026-1104',
    category: 'Limpieza y Desinfección',
    supplier: 'CleanPro Servicios Ambientales y Jardinería',
    supplierTaxId: 'CL-77.904.118-9',
    invoiceNumber: 'FAC-33102',
    description: 'Insumos de aseo industrial, mantención de jardines y cloración piscina',
    issueDate: '2026-11-01',
    dueDate: '2026-11-15',
    amount: 620.00,
    status: 'Pendiente'
  },
  {
    id: 'exp-05',
    condoId: 'condo-1',
    expenseNumber: 'EGR-2026-1105',
    category: 'Seguros',
    supplier: 'Chubb Seguros de Incendio y Espacios Comunes',
    supplierTaxId: 'CL-99.102.400-K',
    invoiceNumber: 'POL-CH-77401',
    description: 'Póliza colectiva obligatoria contra incendios y sismos cuota 11/12',
    issueDate: '2026-10-20',
    dueDate: '2026-11-05',
    amount: 780.00,
    status: 'Pendiente'
  }
];

export const initialTickets: MaintenanceTicket[] = [
  {
    id: 'tkt-01',
    condoId: 'condo-1',
    unitNumber: 'Torre A',
    title: 'Ajuste sensor de cierre en Ascensor Torre A',
    description: 'Las puertas del ascensor 2 en el piso 4 presentan apertura intermitente con retardo de 5 segundos.',
    location: 'Ascensor #2 Torre A',
    category: 'Ascensores',
    priority: 'Alta',
    status: 'En Proceso',
    assignedTo: 'Técnico Schindler - Mauricio Herrera',
    reportedBy: 'Conserje Turno Mañana',
    reportedDate: '2026-10-31',
    estimatedCost: 120.00
  },
  {
    id: 'tkt-02',
    condoId: 'condo-1',
    location: 'Sala de Bombas Subterráneo -2',
    title: 'Inspección de presión bomba presurizadora #1',
    description: 'Verificación preventiva trimestral del manómetro y válvulas de retención.',
    category: 'Bombas de Agua',
    priority: 'Media',
    status: 'Resuelto',
    assignedTo: 'Hidráulica Sanitaria del Sur Ltda.',
    reportedBy: 'Administración Condolink',
    reportedDate: '2026-10-28',
    estimatedCost: 95.00,
    actualCost: 95.00,
    resolutionDate: '2026-10-30'
  },
  {
    id: 'tkt-03',
    condoId: 'condo-1',
    location: 'Portón Vehicular Principal Acceso Poniente',
    title: 'Calibración motor batiente portón vehicular',
    description: 'El portón derecho presenta leve desaceleración al llegar al tope magnético.',
    category: 'Cerrajería/Portón',
    priority: 'Media',
    status: 'Reportado',
    assignedTo: 'Automatismos Seguritec',
    reportedBy: 'Seguridad Acceso',
    reportedDate: '2026-11-01',
    estimatedCost: 80.00
  }
];

export const initialAmenities: Amenity[] = [
  {
    id: 'amenity-1',
    condoId: 'condo-1',
    name: 'Quincho & Terraza Panorámica Torre A',
    capacity: 25,
    bookingFee: 35.00,
    cleaningDeposit: 50.00,
    rules: 'Uso exclusivo hasta las 23:30 hrs. Prohibido música amplificada que sobrepase decibeles normados. Entrega limpia.',
    availableHours: '12:00 a 17:00 / 18:30 a 23:30',
    iconType: 'quincho'
  },
  {
    id: 'amenity-2',
    condoId: 'condo-1',
    name: 'Salón de Eventos Multiuso Lounge',
    capacity: 50,
    bookingFee: 60.00,
    cleaningDeposit: 80.00,
    rules: 'Aforo máximo 50 personas. Requiere lista de invitados 24 horas antes en conserjería para control de acceso.',
    availableHours: '10:00 a 16:00 / 18:00 a 00:00',
    iconType: 'salon'
  },
  {
    id: 'amenity-3',
    condoId: 'condo-1',
    name: 'Piscina Olímpica y Solárium',
    capacity: 40,
    bookingFee: 0.00,
    cleaningDeposit: 0.00,
    rules: 'Horario libre de martes a domingo (lunes mantención química). Niños menores de 12 deben estar con tutor.',
    availableHours: '09:00 a 20:30',
    iconType: 'piscina'
  },
  {
    id: 'amenity-4',
    condoId: 'condo-1',
    name: 'Cancha de Pádel Vidrio Templado',
    capacity: 4,
    bookingFee: 15.00,
    cleaningDeposit: 0.00,
    rules: 'Turnos de 90 minutos por reserva. Uso obligatorio de calzado deportivo adecuado.',
    availableHours: '07:00 a 22:00',
    iconType: 'padel'
  }
];

export const initialReservations: AmenityReservation[] = [
  {
    id: 'resv-01',
    condoId: 'condo-1',
    amenityId: 'amenity-1',
    amenityName: 'Quincho & Terraza Panorámica Torre A',
    unitNumber: '201',
    residentName: 'Dra. Carmen Gloria Fuentes',
    date: '2026-11-07',
    timeSlot: '18:30 a 23:30',
    status: 'Confirmada',
    feePaid: true,
    totalCost: 85.00
  },
  {
    id: 'resv-02',
    condoId: 'condo-1',
    amenityId: 'amenity-4',
    amenityName: 'Cancha de Pádel Vidrio Templado',
    unitNumber: '101',
    residentName: 'Alejandro Morales Rivas',
    date: '2026-11-03',
    timeSlot: '19:00 a 20:30',
    status: 'Confirmada',
    feePaid: true,
    totalCost: 15.00
  }
];

export const initialVisitors: VisitorLog[] = [
  {
    id: 'vis-01',
    condoId: 'condo-1',
    visitorName: 'Rodrigo Santibáñez',
    visitorId: '17.209.441-3',
    unitVisited: '101',
    vehiclePlate: 'LX-88-21',
    entryTimestamp: '2026-11-01 10:15',
    visitorType: 'Visita',
    authorizedBy: 'Alejandro Morales (Vía Intercom)',
    guardOnDuty: 'Conserje Manuel Pinto'
  },
  {
    id: 'vis-02',
    condoId: 'condo-1',
    visitorName: 'Repartidor Mercado Libre',
    visitorId: 'ML-99218',
    unitVisited: '201',
    entryTimestamp: '2026-11-01 11:30',
    exitTimestamp: '2026-11-01 11:38',
    visitorType: 'Delivery/Repartidor',
    authorizedBy: 'Recepción y entrega en conserjería',
    guardOnDuty: 'Conserje Manuel Pinto'
  },
  {
    id: 'vis-03',
    condoId: 'condo-1',
    visitorName: 'Mauricio Herrera (Schindler)',
    visitorId: '13.550.910-1',
    unitVisited: 'Sala de Máquinas',
    vehiclePlate: 'HV-70-19',
    entryTimestamp: '2026-11-01 08:30',
    visitorType: 'Contratista/Técnico',
    authorizedBy: 'Administración Condolink',
    guardOnDuty: 'Conserje Manuel Pinto'
  }
];

export const initialPackages: PackageLog[] = [
  {
    id: 'pkg-01',
    condoId: 'condo-1',
    unitNumber: '201',
    recipientName: 'Carmen Gloria Fuentes',
    courier: 'Amazon',
    trackingNumber: 'TBA-8491028401',
    description: 'Caja mediana sellada sellos oficiales',
    receivedDate: '2026-11-01 11:35',
    status: 'En Conserjería',
    receivedByGuard: 'Conserje Manuel Pinto'
  },
  {
    id: 'pkg-02',
    condoId: 'condo-1',
    unitNumber: '101',
    recipientName: 'Alejandro Morales Rivas',
    courier: 'Chilexpress',
    trackingNumber: 'CHX-99401284',
    description: 'Sobre acolchado documentación comercial',
    receivedDate: '2026-10-31 16:20',
    deliveredDate: '2026-10-31 19:40',
    status: 'Entregado al Residente',
    receivedByGuard: 'Conserje Roberto Lagos',
    deliveredToPerson: 'Alejandro Morales Rivas (Firma registrada)'
  }
];

export const initialAssemblies: AssemblyMeeting[] = [
  {
    id: 'ass-01',
    condoId: 'condo-1',
    title: 'Asamblea Ordinaria Anual de Copropietarios 2026',
    type: 'Ordinaria',
    date: '2026-11-20',
    time: '19:30 hrs',
    location: 'Salón de Eventos Lounge + Transmisión Online Condolink',
    agenda: [
      '1. Aprobación del Balance Financiero Ejercicio 2025-2026',
      '2. Presentación y votación del Presupuesto Operativo 2027',
      '3. Renovación de contratos de seguridad y mantención de ascensores',
      '4. Elección del nuevo Comité de Administración'
    ],
    quorumRequiredPercentage: 50.0,
    currentQuorumPercentage: 68.4,
    status: 'Convocada',
    votes: [
      {
        id: 'vote-01',
        topic: 'Aprobación del Presupuesto Operativo 2027 (+3.5% IPC)',
        inFavorPercent: 78.5,
        againstPercent: 14.2,
        abstainPercent: 7.3,
        resolved: true
      },
      {
        id: 'vote-02',
        topic: 'Instalación de paneles solares fotovoltaicos para iluminación común',
        inFavorPercent: 88.0,
        againstPercent: 8.0,
        abstainPercent: 4.0,
        resolved: true
      }
    ]
  }
];

export const initialNotices: OfficialNotice[] = [
  {
    id: 'not-01',
    condoId: 'condo-1',
    title: 'Convocatoria Oficial: Asamblea Ordinaria de Copropietarios',
    category: 'Financiero',
    date: '2026-10-29',
    author: 'Comité de Administración & Condolink Global',
    content: 'Se cita a todos los copropietarios a la asamblea anual fijada para el 20 de noviembre a las 19:30 hrs en primer llamado y 20:00 hrs en segundo llamado. Podrán participar de forma presencial o remota mediante el portal Condolink.',
    pinned: true
  },
  {
    id: 'not-02',
    condoId: 'condo-1',
    title: 'Mantenimiento Preventivo de Bombas de Agua Potable',
    category: 'Mantenimiento',
    date: '2026-10-27',
    author: 'Administración Técnica',
    content: 'Informamos que este martes se realizó con total éxito la calibración de válvulas y presurizadores. No se requirió corte de suministro gracias al sistema redundante.',
    pinned: false
  },
  {
    id: 'not-03',
    condoId: 'condo-1',
    title: 'Actualización Protocolo de Seguridad en Accesos y Visitas',
    category: 'Convivencia',
    date: '2026-10-25',
    author: 'Jefatura de Seguridad',
    content: 'Recordamos a todos los residentes registrar previamente a contratistas o visitas nocturnas mediante la suite para agilizar el ingreso vehicular en portería.',
    pinned: false
  }
];

export const initialSettings: AppSettings = {
  currencySymbol: '$',
  currencyCode: 'USD',
  lateFeeInterestMonthly: 2.5,
  reserveFundLegalMinPercent: 5.0,
  invoiceDueDayOfMonth: 15,
  systemName: 'Condolink Global V20.8',
  version: 'V20.8 - Suite Ejecutivo Administrativo',
  organizationName: 'Condolink Global Real Estate & Admin S.A.',
  supportEmail: 'condolinkglobal@gmail.com'
};
