export type CondominiumId = string;

export interface Condominium {
  id: string;
  name: string;
  code: string;
  address: string;
  city: string;
  totalUnits: number;
  administrator: string;
  adminEmail: string;
  taxId: string; // RUT / RFC / NIF
  bankName: string;
  bankAccount: string;
  currency: string;
  reserveFundPercentage: number; // e.g. 5%
  defaultLateFeePercentage: number; // e.g. 2%
}

export type UnitType = 'Apartamento' | 'Casa' | 'Oficina' | 'Local Comercial' | 'Penthouse';
export type OccupancyStatus = 'Propietario Residente' | 'Arrendado' | 'Desocupado' | 'En Remodelación';
export type PaymentStatus = 'Solvente' | 'En Mora' | 'Con Saldo a Favor';

export interface Resident {
  id: string;
  unitId: string;
  condoId: string;
  name: string;
  rutOrId: string;
  email: string;
  phone: string;
  isOwner: boolean;
  occupantType: 'Propietario' | 'Inquilino' | 'Copropietario';
  vehicles: string[]; // license plates
  pets: string[];
  accessCards: string[];
}

export interface Unit {
  id: string;
  condoId: string;
  unitNumber: string;
  towerOrBlock: string;
  floor: number;
  type: UnitType;
  areaSqMeters: number;
  aliquotPercentage: number; // e.g. 2.45%
  parkingSpots: string;
  storageUnit: string;
  occupancyStatus: OccupancyStatus;
  currentBalance: number; // positive = owes, negative = credit
  paymentStatus: PaymentStatus;
  primaryResidentName: string;
  primaryResidentEmail: string;
  primaryResidentPhone: string;
  unpaidMonthsCount: number;
}

export interface MaintenanceFeeInvoice {
  id: string;
  invoiceNumber: string;
  condoId: string;
  unitId: string;
  unitNumber: string;
  residentName: string;
  period: string; // e.g., 'Noviembre 2026'
  issueDate: string;
  dueDate: string;
  baseCommonFee: number;
  reserveFundAmount: number;
  waterOrUtilityAmount: number;
  parkingOrExtraFee: number;
  penaltiesOrLateFee: number;
  totalAmount: number;
  amountPaid: number;
  balanceRemaining: number;
  status: 'Pagado' | 'Pendiente' | 'Vencido' | 'Parcial';
}

export interface PaymentRecord {
  id: string;
  receiptNumber: string;
  condoId: string;
  unitId: string;
  unitNumber: string;
  payerName: string;
  paymentDate: string;
  amount: number;
  paymentMethod: 'Transferencia Bancaria' | 'Depósito' | 'Tarjeta de Débito/Crédito' | 'Cheque' | 'Efectivo';
  referenceNumber: string;
  destinationAccount: string;
  concept: string; // e.g., 'Gasto Común Noviembre 2026 + Reserva Quincho'
  notes?: string;
  verifiedBy: string;
}

export interface ExpenseRecord {
  id: string;
  condoId: string;
  expenseNumber: string;
  category: 'Servicios Básicos (Luz/Agua)' | 'Mantenimiento y Reparaciones' | 'Seguridad y Vigilancia' | 'Limpieza y Desinfección' | 'Honorarios Administración' | 'Seguros' | 'Otros';
  supplier: string;
  supplierTaxId: string;
  invoiceNumber: string;
  description: string;
  issueDate: string;
  dueDate: string;
  paymentDate?: string;
  amount: number;
  status: 'Pagado' | 'Pendiente' | 'En Aprobación';
  paymentMethod?: string;
  referenceDoc?: string;
}

export interface MaintenanceTicket {
  id: string;
  condoId: string;
  unitNumber?: string;
  title: string;
  description: string;
  location: string; // e.g. 'Ascensor Torre A', 'Bomba Hidráulica 2'
  category: 'Ascensores' | 'Bombas de Agua' | 'Electricidad' | 'Piscina/Áreas Verdes' | 'Cerrajería/Portón' | 'Estructural';
  priority: 'Baja' | 'Media' | 'Alta' | 'Urgente';
  status: 'Reportado' | 'En Proceso' | 'Repuestos Solicitados' | 'Resuelto';
  assignedTo: string;
  reportedBy: string;
  reportedDate: string;
  estimatedCost: number;
  actualCost?: number;
  resolutionDate?: string;
}

export interface Amenity {
  id: string;
  condoId: string;
  name: string;
  capacity: number;
  bookingFee: number;
  cleaningDeposit: number;
  rules: string;
  availableHours: string;
  iconType: 'piscina' | 'quincho' | 'salon' | 'gimnasio' | 'padel';
}

export interface AmenityReservation {
  id: string;
  condoId: string;
  amenityId: string;
  amenityName: string;
  unitNumber: string;
  residentName: string;
  date: string;
  timeSlot: string;
  status: 'Confirmada' | 'Pendiente de Pago' | 'Cancelada';
  feePaid: boolean;
  totalCost: number;
}

export interface VisitorLog {
  id: string;
  condoId: string;
  visitorName: string;
  visitorId: string;
  unitVisited: string;
  vehiclePlate?: string;
  entryTimestamp: string;
  exitTimestamp?: string;
  visitorType: 'Visita' | 'Delivery/Repartidor' | 'Contratista/Técnico' | 'Mudanza';
  authorizedBy: string;
  guardOnDuty: string;
}

export interface PackageLog {
  id: string;
  condoId: string;
  unitNumber: string;
  recipientName: string;
  courier: 'Chilexpress' | 'MercadoLibre' | 'Amazon' | 'Correos' | 'FedEx/DHL' | 'Otro';
  trackingNumber: string;
  description: string;
  receivedDate: string;
  deliveredDate?: string;
  status: 'En Conserjería' | 'Entregado al Residente';
  receivedByGuard: string;
  deliveredToPerson?: string;
}

export interface AssemblyMeeting {
  id: string;
  condoId: string;
  title: string;
  type: 'Ordinaria' | 'Extraordinaria';
  date: string;
  time: string;
  location: string;
  agenda: string[];
  quorumRequiredPercentage: number; // e.g. 50%
  currentQuorumPercentage: number;
  status: 'Convocada' | 'En Curso' | 'Finalizada' | 'Acta Aprobada';
  votes: {
    id: string;
    topic: string;
    inFavorPercent: number;
    againstPercent: number;
    abstainPercent: number;
    resolved: boolean;
  }[];
}

export interface OfficialNotice {
  id: string;
  condoId: string;
  title: string;
  category: 'Urgente' | 'Mantenimiento' | 'Financiero' | 'Convivencia' | 'Informativo';
  date: string;
  author: string;
  content: string;
  pinned: boolean;
}

export interface AppSettings {
  currencySymbol: string;
  currencyCode: string;
  lateFeeInterestMonthly: number;
  reserveFundLegalMinPercent: number;
  invoiceDueDayOfMonth: number;
  systemName: string;
  version: string;
  organizationName: string;
  supportEmail: string;
}
