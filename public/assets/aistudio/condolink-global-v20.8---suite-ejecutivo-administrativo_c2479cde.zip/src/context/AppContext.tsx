import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Condominium,
  Unit,
  MaintenanceFeeInvoice,
  PaymentRecord,
  ExpenseRecord,
  MaintenanceTicket,
  Amenity,
  AmenityReservation,
  VisitorLog,
  PackageLog,
  AssemblyMeeting,
  OfficialNotice,
  AppSettings
} from '../types/index.ts';
import {
  initialCondominiums,
  initialUnits,
  initialInvoices,
  initialPayments,
  initialExpenses,
  initialTickets,
  initialAmenities,
  initialReservations,
  initialVisitors,
  initialPackages,
  initialAssemblies,
  initialNotices,
  initialSettings
} from '../data/mockData.ts';

export type UserRole = 'ADMIN_EJECUTIVO' | 'CONTADOR' | 'CONSERJERIA' | 'RESIDENTE';

interface AppContextType {
  condominiums: Condominium[];
  selectedCondoId: string;
  setSelectedCondoId: (id: string) => void;
  selectedCondo: Condominium | null;
  units: Unit[];
  invoices: MaintenanceFeeInvoice[];
  payments: PaymentRecord[];
  expenses: ExpenseRecord[];
  tickets: MaintenanceTicket[];
  amenities: Amenity[];
  reservations: AmenityReservation[];
  visitors: VisitorLog[];
  packages: PackageLog[];
  assemblies: AssemblyMeeting[];
  notices: OfficialNotice[];
  settings: AppSettings;
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  selectedResidentUnitId: string;
  setSelectedResidentUnitId: (unitId: string) => void;
  
  // Modals for official docs
  activeReceipt: PaymentRecord | null;
  setActiveReceipt: (receipt: PaymentRecord | null) => void;
  activePazYSalvoUnit: Unit | null;
  setActivePazYSalvoUnit: (unit: Unit | null) => void;

  // Actions
  addCondominium: (condo: Omit<Condominium, 'id'>) => void;
  addUnit: (unit: Omit<Unit, 'id' | 'currentBalance' | 'paymentStatus' | 'unpaidMonthsCount'>) => void;
  updateUnit: (unit: Unit) => void;
  deleteUnit: (id: string) => void;
  generateMonthlyInvoices: (period: string, dueDate: string, baseMultiplier?: number) => { count: number; total: number };
  recordPayment: (payment: Omit<PaymentRecord, 'id' | 'receiptNumber'>) => PaymentRecord;
  recordExpense: (expense: Omit<ExpenseRecord, 'id' | 'expenseNumber'>) => void;
  markExpensePaid: (id: string, paymentMethod: string) => void;
  createTicket: (ticket: Omit<MaintenanceTicket, 'id' | 'reportedDate' | 'status'>) => void;
  updateTicketStatus: (id: string, status: MaintenanceTicket['status'], actualCost?: number) => void;
  createReservation: (resv: Omit<AmenityReservation, 'id' | 'status' | 'feePaid'>) => void;
  cancelReservation: (id: string) => void;
  logVisitor: (visitor: Omit<VisitorLog, 'id' | 'entryTimestamp'>) => void;
  checkoutVisitor: (id: string) => void;
  logPackage: (pkg: Omit<PackageLog, 'id' | 'receivedDate' | 'status'>) => void;
  deliverPackage: (id: string, receiverName: string) => void;
  createNotice: (notice: Omit<OfficialNotice, 'id' | 'date'>) => void;
  deleteNotice: (id: string) => void;
  castVote: (assemblyId: string, voteId: string, choice: 'favor' | 'contra' | 'abstencion') => void;
  updateSettings: (newSettings: Partial<AppSettings>) => void;
  resetAllData: () => void;
  exportDatabaseJSON: () => void;
  importDatabaseJSON: (jsonString: string) => boolean;
}

const STORAGE_KEY = 'condolink_v20_8_executive_data';

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load state from localStorage or fallback
  const loadState = <T,>(key: string, fallback: T): T => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY}_${key}`);
      return stored ? JSON.parse(stored) : fallback;
    } catch {
      return fallback;
    }
  };

  const [condominiums, setCondominiums] = useState<Condominium[]>(() => loadState('condos', initialCondominiums));
  const [selectedCondoId, setSelectedCondoId] = useState<string>('all');
  const [units, setUnits] = useState<Unit[]>(() => loadState('units', initialUnits));
  const [invoices, setInvoices] = useState<MaintenanceFeeInvoice[]>(() => loadState('invoices', initialInvoices));
  const [payments, setPayments] = useState<PaymentRecord[]>(() => loadState('payments', initialPayments));
  const [expenses, setExpenses] = useState<ExpenseRecord[]>(() => loadState('expenses', initialExpenses));
  const [tickets, setTickets] = useState<MaintenanceTicket[]>(() => loadState('tickets', initialTickets));
  const [amenities, setAmenities] = useState<Amenity[]>(() => loadState('amenities', initialAmenities));
  const [reservations, setReservations] = useState<AmenityReservation[]>(() => loadState('reservations', initialReservations));
  const [visitors, setVisitors] = useState<VisitorLog[]>(() => loadState('visitors', initialVisitors));
  const [packages, setPackages] = useState<PackageLog[]>(() => loadState('packages', initialPackages));
  const [assemblies, setAssemblies] = useState<AssemblyMeeting[]>(() => loadState('assemblies', initialAssemblies));
  const [notices, setNotices] = useState<OfficialNotice[]>(() => loadState('notices', initialNotices));
  const [settings, setSettings] = useState<AppSettings>(() => loadState('settings', initialSettings));
  
  const [currentRole, setCurrentRole] = useState<UserRole>('ADMIN_EJECUTIVO');
  const [selectedResidentUnitId, setSelectedResidentUnitId] = useState<string>('unit-101');
  
  const [activeReceipt, setActiveReceipt] = useState<PaymentRecord | null>(null);
  const [activePazYSalvoUnit, setActivePazYSalvoUnit] = useState<Unit | null>(null);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_condos`, JSON.stringify(condominiums));
    localStorage.setItem(`${STORAGE_KEY}_units`, JSON.stringify(units));
    localStorage.setItem(`${STORAGE_KEY}_invoices`, JSON.stringify(invoices));
    localStorage.setItem(`${STORAGE_KEY}_payments`, JSON.stringify(payments));
    localStorage.setItem(`${STORAGE_KEY}_expenses`, JSON.stringify(expenses));
    localStorage.setItem(`${STORAGE_KEY}_tickets`, JSON.stringify(tickets));
    localStorage.setItem(`${STORAGE_KEY}_amenities`, JSON.stringify(amenities));
    localStorage.setItem(`${STORAGE_KEY}_reservations`, JSON.stringify(reservations));
    localStorage.setItem(`${STORAGE_KEY}_visitors`, JSON.stringify(visitors));
    localStorage.setItem(`${STORAGE_KEY}_packages`, JSON.stringify(packages));
    localStorage.setItem(`${STORAGE_KEY}_assemblies`, JSON.stringify(assemblies));
    localStorage.setItem(`${STORAGE_KEY}_notices`, JSON.stringify(notices));
    localStorage.setItem(`${STORAGE_KEY}_settings`, JSON.stringify(settings));
  }, [condominiums, units, invoices, payments, expenses, tickets, amenities, reservations, visitors, packages, assemblies, notices, settings]);

  const selectedCondo = selectedCondoId === 'all' 
    ? null 
    : condominiums.find(c => c.id === selectedCondoId) || null;

  // Actions
  const addCondominium = (condoData: Omit<Condominium, 'id'>) => {
    const newCondo: Condominium = {
      ...condoData,
      id: `condo-${Date.now()}`
    };
    setCondominiums(prev => [...prev, newCondo]);
  };

  const addUnit = (unitData: Omit<Unit, 'id' | 'currentBalance' | 'paymentStatus' | 'unpaidMonthsCount'>) => {
    const newUnit: Unit = {
      ...unitData,
      id: `unit-${Date.now()}`,
      currentBalance: 0,
      paymentStatus: 'Solvente',
      unpaidMonthsCount: 0
    };
    setUnits(prev => [...prev, newUnit]);
  };

  const updateUnit = (updatedUnit: Unit) => {
    setUnits(prev => prev.map(u => u.id === updatedUnit.id ? updatedUnit : u));
  };

  const deleteUnit = (id: string) => {
    setUnits(prev => prev.filter(u => u.id !== id));
  };

  const generateMonthlyInvoices = (period: string, dueDate: string, baseMultiplier: number = 2.0) => {
    const targetCondoUnits = selectedCondoId === 'all' 
      ? units 
      : units.filter(u => u.condoId === selectedCondoId);

    const generated: MaintenanceFeeInvoice[] = [];
    const updatedUnits = [...units];

    targetCondoUnits.forEach((unit, index) => {
      // Base fee calculated by square meters or aliquot
      const baseFee = Math.round(unit.areaSqMeters * baseMultiplier * 100) / 100;
      const reserveFund = Math.round(baseFee * 0.05 * 100) / 100;
      const utilityShare = Math.round((20 + (unit.floor * 1.5)) * 100) / 100;
      const parkingFee = unit.parkingSpots ? 15.00 : 0.00;
      const total = Math.round((baseFee + reserveFund + utilityShare + parkingFee) * 100) / 100;

      const invNumber = `GC-${period.replace(/\s+/g, '-').toUpperCase()}-${String(index + 1).padStart(3, '0')}`;
      
      const newInvoice: MaintenanceFeeInvoice = {
        id: `inv-${Date.now()}-${unit.id}`,
        invoiceNumber: invNumber,
        condoId: unit.condoId,
        unitId: unit.id,
        unitNumber: unit.unitNumber,
        residentName: unit.primaryResidentName,
        period,
        issueDate: new Date().toISOString().split('T')[0],
        dueDate,
        baseCommonFee: baseFee,
        reserveFundAmount: reserveFund,
        waterOrUtilityAmount: utilityShare,
        parkingOrExtraFee: parkingFee,
        penaltiesOrLateFee: 0,
        totalAmount: total,
        amountPaid: 0,
        balanceRemaining: total,
        status: 'Pendiente'
      };

      generated.push(newInvoice);

      // Update unit balance
      const uIdx = updatedUnits.findIndex(u => u.id === unit.id);
      if (uIdx !== -1) {
        const newBalance = Math.round((updatedUnits[uIdx].currentBalance + total) * 100) / 100;
        updatedUnits[uIdx] = {
          ...updatedUnits[uIdx],
          currentBalance: newBalance,
          paymentStatus: newBalance > 0 ? 'En Mora' : newBalance < 0 ? 'Con Saldo a Favor' : 'Solvente',
          unpaidMonthsCount: updatedUnits[uIdx].unpaidMonthsCount + 1
        };
      }
    });

    setInvoices(prev => [...generated, ...prev]);
    setUnits(updatedUnits);

    return {
      count: generated.length,
      total: generated.reduce((sum, inv) => sum + inv.totalAmount, 0)
    };
  };

  const recordPayment = (paymentData: Omit<PaymentRecord, 'id' | 'receiptNumber'>): PaymentRecord => {
    const receiptNum = `REC-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;
    const newPayment: PaymentRecord = {
      ...paymentData,
      id: `pay-${Date.now()}`,
      receiptNumber: receiptNum
    };

    setPayments(prev => [newPayment, ...prev]);

    // Update corresponding unit
    setUnits(prev => prev.map(unit => {
      if (unit.id === paymentData.unitId) {
        const updatedBal = Math.round((unit.currentBalance - paymentData.amount) * 100) / 100;
        return {
          ...unit,
          currentBalance: updatedBal,
          paymentStatus: updatedBal <= 0 ? (updatedBal < 0 ? 'Con Saldo a Favor' : 'Solvente') : 'En Mora',
          unpaidMonthsCount: updatedBal <= 0 ? 0 : unit.unpaidMonthsCount
        };
      }
      return unit;
    }));

    // Reconcile pending invoices for this unit
    setInvoices(prev => {
      let remainingPayment = paymentData.amount;
      return prev.map(inv => {
        if (inv.unitId === paymentData.unitId && inv.status !== 'Pagado' && remainingPayment > 0) {
          const needed = inv.balanceRemaining;
          if (remainingPayment >= needed) {
            remainingPayment -= needed;
            return {
              ...inv,
              amountPaid: inv.totalAmount,
              balanceRemaining: 0,
              status: 'Pagado'
            };
          } else {
            const newPaid = inv.amountPaid + remainingPayment;
            const newRemaining = inv.totalAmount - newPaid;
            remainingPayment = 0;
            return {
              ...inv,
              amountPaid: newPaid,
              balanceRemaining: newRemaining,
              status: 'Parcial'
            };
          }
        }
        return inv;
      });
    });

    return newPayment;
  };

  const recordExpense = (expenseData: Omit<ExpenseRecord, 'id' | 'expenseNumber'>) => {
    const expNumber = `EGR-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const newExpense: ExpenseRecord = {
      ...expenseData,
      id: `exp-${Date.now()}`,
      expenseNumber: expNumber
    };
    setExpenses(prev => [newExpense, ...prev]);
  };

  const markExpensePaid = (id: string, paymentMethod: string) => {
    setExpenses(prev => prev.map(exp => {
      if (exp.id === id) {
        return {
          ...exp,
          status: 'Pagado',
          paymentDate: new Date().toISOString().split('T')[0],
          paymentMethod
        };
      }
      return exp;
    }));
  };

  const createTicket = (ticketData: Omit<MaintenanceTicket, 'id' | 'reportedDate' | 'status'>) => {
    const newTicket: MaintenanceTicket = {
      ...ticketData,
      id: `tkt-${Date.now()}`,
      reportedDate: new Date().toISOString().split('T')[0],
      status: 'Reportado'
    };
    setTickets(prev => [newTicket, ...prev]);
  };

  const updateTicketStatus = (id: string, status: MaintenanceTicket['status'], actualCost?: number) => {
    setTickets(prev => prev.map(tkt => {
      if (tkt.id === id) {
        return {
          ...tkt,
          status,
          actualCost: actualCost !== undefined ? actualCost : tkt.actualCost,
          resolutionDate: status === 'Resuelto' ? new Date().toISOString().split('T')[0] : tkt.resolutionDate
        };
      }
      return tkt;
    }));
  };

  const createReservation = (resvData: Omit<AmenityReservation, 'id' | 'status' | 'feePaid'>) => {
    const newResv: AmenityReservation = {
      ...resvData,
      id: `resv-${Date.now()}`,
      status: 'Confirmada',
      feePaid: true
    };
    setReservations(prev => [newResv, ...prev]);
  };

  const cancelReservation = (id: string) => {
    setReservations(prev => prev.map(r => r.id === id ? { ...r, status: 'Cancelada' } : r));
  };

  const logVisitor = (visitorData: Omit<VisitorLog, 'id' | 'entryTimestamp'>) => {
    const now = new Date();
    const timeStr = `${now.toISOString().split('T')[0]} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const newVisitor: VisitorLog = {
      ...visitorData,
      id: `vis-${Date.now()}`,
      entryTimestamp: timeStr
    };
    setVisitors(prev => [newVisitor, ...prev]);
  };

  const checkoutVisitor = (id: string) => {
    const now = new Date();
    const timeStr = `${now.toISOString().split('T')[0]} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    setVisitors(prev => prev.map(v => v.id === id ? { ...v, exitTimestamp: timeStr } : v));
  };

  const logPackage = (pkgData: Omit<PackageLog, 'id' | 'receivedDate' | 'status'>) => {
    const now = new Date();
    const timeStr = `${now.toISOString().split('T')[0]} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const newPkg: PackageLog = {
      ...pkgData,
      id: `pkg-${Date.now()}`,
      receivedDate: timeStr,
      status: 'En Conserjería'
    };
    setPackages(prev => [newPkg, ...prev]);
  };

  const deliverPackage = (id: string, receiverName: string) => {
    const now = new Date();
    const timeStr = `${now.toISOString().split('T')[0]} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    setPackages(prev => prev.map(p => p.id === id ? {
      ...p,
      status: 'Entregado al Residente',
      deliveredDate: timeStr,
      deliveredToPerson: receiverName
    } : p));
  };

  const createNotice = (noticeData: Omit<OfficialNotice, 'id' | 'date'>) => {
    const newNotice: OfficialNotice = {
      ...noticeData,
      id: `not-${Date.now()}`,
      date: new Date().toISOString().split('T')[0]
    };
    setNotices(prev => [newNotice, ...prev]);
  };

  const deleteNotice = (id: string) => {
    setNotices(prev => prev.filter(n => n.id !== id));
  };

  const castVote = (assemblyId: string, voteId: string, choice: 'favor' | 'contra' | 'abstencion') => {
    setAssemblies(prev => prev.map(ass => {
      if (ass.id === assemblyId) {
        return {
          ...ass,
          votes: ass.votes.map(v => {
            if (v.id === voteId) {
              const delta = 2.5;
              if (choice === 'favor') return { ...v, inFavorPercent: Math.min(100, v.inFavorPercent + delta) };
              if (choice === 'contra') return { ...v, againstPercent: Math.min(100, v.againstPercent + delta) };
              return { ...v, abstainPercent: Math.min(100, v.abstainPercent + delta) };
            }
            return v;
          })
        };
      }
      return ass;
    }));
  };

  const updateSettings = (newSettings: Partial<AppSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const resetAllData = () => {
    localStorage.clear();
    setCondominiums(initialCondominiums);
    setUnits(initialUnits);
    setInvoices(initialInvoices);
    setPayments(initialPayments);
    setExpenses(initialExpenses);
    setTickets(initialTickets);
    setAmenities(initialAmenities);
    setReservations(initialReservations);
    setVisitors(initialVisitors);
    setPackages(initialPackages);
    setAssemblies(initialAssemblies);
    setNotices(initialNotices);
    setSettings(initialSettings);
  };

  const exportDatabaseJSON = () => {
    const data = {
      condominiums,
      units,
      invoices,
      payments,
      expenses,
      tickets,
      amenities,
      reservations,
      visitors,
      packages,
      assemblies,
      notices,
      settings,
      exportTimestamp: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Condolink_Global_V20.8_Backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const importDatabaseJSON = (jsonString: string): boolean => {
    try {
      const data = JSON.parse(jsonString);
      if (data.condominiums && data.units) {
        if (data.condominiums) setCondominiums(data.condominiums);
        if (data.units) setUnits(data.units);
        if (data.invoices) setInvoices(data.invoices);
        if (data.payments) setPayments(data.payments);
        if (data.expenses) setExpenses(data.expenses);
        if (data.tickets) setTickets(data.tickets);
        if (data.amenities) setAmenities(data.amenities);
        if (data.reservations) setReservations(data.reservations);
        if (data.visitors) setVisitors(data.visitors);
        if (data.packages) setPackages(data.packages);
        if (data.assemblies) setAssemblies(data.assemblies);
        if (data.notices) setNotices(data.notices);
        if (data.settings) setSettings(data.settings);
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  return (
    <AppContext.Provider
      value={{
        condominiums,
        selectedCondoId,
        setSelectedCondoId,
        selectedCondo,
        units,
        invoices,
        payments,
        expenses,
        tickets,
        amenities,
        reservations,
        visitors,
        packages,
        assemblies,
        notices,
        settings,
        currentRole,
        setCurrentRole,
        selectedResidentUnitId,
        setSelectedResidentUnitId,
        activeReceipt,
        setActiveReceipt,
        activePazYSalvoUnit,
        setActivePazYSalvoUnit,
        addCondominium,
        addUnit,
        updateUnit,
        deleteUnit,
        generateMonthlyInvoices,
        recordPayment,
        recordExpense,
        markExpensePaid,
        createTicket,
        updateTicketStatus,
        createReservation,
        cancelReservation,
        logVisitor,
        checkoutVisitor,
        logPackage,
        deliverPackage,
        createNotice,
        deleteNotice,
        castVote,
        updateSettings,
        resetAllData,
        exportDatabaseJSON,
        importDatabaseJSON
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
