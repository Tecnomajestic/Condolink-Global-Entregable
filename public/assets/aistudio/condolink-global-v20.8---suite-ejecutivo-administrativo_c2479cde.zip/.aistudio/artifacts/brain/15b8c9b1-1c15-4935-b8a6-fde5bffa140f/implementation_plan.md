# Condolink Global V20.8 — Plan de Migración Relacional a Supabase y Desbloqueo Integral del Ecosistema Admin, Junta y Master

Este plan detalla la arquitectura de datos relacional en Supabase PostgreSQL para las 13 entidades del ecosistema Condolink Global V20.8, el motor de sincronización dual en tiempo real entre Supabase y el respaldo local JSON, y el desbloqueo operativo completo de los paneles Master, Administrador y Junta de Condominio (incluyendo hidratación de identidad corporativa y logo institucional, creación de propiedades y usuarios Junta, identificación del botón de carga de ficha en Master y terminal de logs desplegable sin duplicación).

---

## Decisiones Confirmadas por el Usuario

1. **Esquema de Base de Datos en Supabase PostgreSQL:**
   - **Tablas relacionales con columnas tipadas y respaldo `JSONB`**: Las 13 entidades (`usuarios`, `administradores`, `inversionistas`, `juntas`, `propiedades`, `unidades`, `solicitudes`, `auditoria`, `libro_diario`, `recibos`, `pagos`, `comunicados`, `mensajes`) se estructuran como tablas PostgreSQL nativas con claves primarias, índices de búsqueda rápida y una columna `payload JSONB` para preservar atributos extendidos de cada inquilino sin pérdida de esquema.
2. **Estrategia de Lectura y Escritura (Persistencia):**
   - **Sincronización dual en tiempo real (Supabase + JSON local)**: Cada operación transaccional (aprobación de solicitudes, creación de administradores, alta de propiedades, creación de usuarios Junta, asientos contables y auditoría) persiste simultáneamente en Supabase (REST PostgREST + Storage Bucket `condolink-db-v208`) y en los archivos locales de respaldo, garantizando continuidad operativa instantánea y tolerancia a fallos de red.
   - **Restricción de Infraestructura:** No se habilita ni aprovisiona Cloud SQL en ningún punto del flujo.
3. **Alcance Operativo en la Interfaz (Admin, Junta y Master):**
   - **Incluir migración Supabase y desbloqueo completo de Admin y Master**: Se integran en un mismo ciclo la sincronización con Supabase, la navegación limpia sin bloqueos del DOM en todo el ecosistema Admin, la hidratación automática de datos y logo del Administrador habilitado por Master, el flujo completo de creación de Propiedades y Usuarios Junta con su ecosistema residencial, la identificación visual y funcional del botón de carga en Master, y la terminal de logs única y desplegable para el rol Master.

---

## 1. Overview & Core Concept

**Condolink Global V20.8** opera como una plataforma multi-tenant jerárquica donde la ** Autoridad Master** aprueba solicitudes de prueba (15 días) o contratación de servicios para **Administradores** e **Inversionistas**. Una vez que el Master habilita a un Administrador, este ingresa a su propio ecosistema (`Portal Admin` → `Panel Admin` → `Instalador Tenant Admin`), visualiza de inmediato su ficha corporativa verificada junto con su **Logo Institucional**, registra sus **Propiedades / Condominios** y crea los **Usuarios Junta de Condominio**, quienes a su vez acceden a su portal residencial para gestionar unidades, propietarios, facturación y finanzas.

El núcleo de esta actualización resuelve tres pilares críticos:
- **Persistencia Relacional y Sincronización Dual con Supabase (`https://yajkiybyejznqddnueoa.supabase.co`)**: Transición de un modelo puramente documental a 13 tablas PostgreSQL tipadas con columna `payload JSONB`, manteniendo sincronización bidireccional automática con el almacenamiento local y el bucket de respaldo en la nube.
- **Desbloqueo de Navegación e Hidratación Multi-Tenant (Admin → Junta)**: Eliminación de bloqueos de eventos provocados por reescrituras `document.open()/document.write()` y colisiones de constantes globales, reemplazándolos por navegación limpia con preservación de sesión y carga reactiva del perfil corporativo y logo del Administrador.
- **Claridad Operativa en el Panel Master**: Identificación explícita del botón de carga de solicitudes hacia la Ficha de Revisión y consolidación de la Terminal de Logs en un único panel desplegable exclusivo para Master.

---

## 2. User Experience & Visual Design

### A. Estética y Jerarquía Visual (LCARS / Enterprise Dark Slate)
- **Paleta de Superficies y Estado Semántico**:
  - Fondo principal de consola en pizarra profunda (`#0B1120` y `#0F172A`) con paneles de elevación única (`#1E293B`) delimitados por bordes sutiles de `1px`.
  - Acentos semánticos de alta legibilidad: Esmeralda (`#10B981`) para estados habilitados y sincronización activa en Supabase; Ámbar (`#F59E0B`) para solicitudes pendientes de aprobación o periodos de prueba; Cian (`#00D4FF`) para acciones de navegación e instaladores de ecosistemas; Carmesí (`#EF4444`) para bloqueos de seguridad o revocaciones.
- **Tipografía y Datos Tabulares**:
  - Encabezados geométricos de alto contraste para identificación de portales y títulos de módulos.
  - Uso estricto de numerales tabulares monoespaciados (`tabular-nums` / `JetBrains Mono`) para RIF, códigos de inquilino, marcas de tiempo en la terminal de auditoría, montos financieros y contadores de días de prueba.

### B. Flujo Desbloqueado del Administrador y Creación del Ecosistema Junta
1. **Hidratación Automática al Iniciar Sesión como Administrador Habilitado**:
   - Cuando el Master aprueba una solicitud desde el **Panel Master** o el **Instalador Tenant Admin Master**, el registro del Administrador queda activo con su Razón Social, RIF, Correo, Teléfono, Modalidad (`PRUEBA` o `CONTRATACION`), Enlace a RIF en Drive y **URL de Logo Institucional**.
   - Al entrar al **Portal Admin**, **Panel Admin** o **Instalador Tenant Admin**, la cabecera y el banner `#fichaAdminHabilitadoBanner` cargan automáticamente el **Logo Institucional**, nombre de la administradora, RIF, modalidad activa y contador de propiedades registradas.
2. **Desbloqueo de Todos los Botones del Ecosistema Admin**:
   - Todos los accesos a subpaneles (`Finanzas Admin`, `Bancos`, `Cuentas por Cobrar`, `Cuentas por Pagar`, `Cartelera`, `Informes`, `Configuración`, `Instalador Tenant Admin` y `Retorno al Portal Admin`) navegan mediante transición limpia de URL conservando la sesión activa y el contexto del inquilino (`adminId`), sin congelar los controladores de eventos ni bloquear botones.
3. **Alta de Propiedades y Creación del Usuario Junta + Ecosistema Residencial**:
   - Desde la sección de gestión de propiedades en el **Panel Admin** o desde el **Instalador Tenant Admin**, el Administrador ingresa:
     - **Nombre del Condominio / Propiedad**, **RIF de la Propiedad**, **Cantidad de Unidades / Inmuebles**, **Correo de Contacto**, **Usuario Junta** (ej. `junta_torres_sol`) y **Clave / PIN de Acceso**.
   - Al pulsar el botón de creación, el sistema registra de forma atómica:
     1. El inmueble en la entidad `propiedades` vinculado al `adminId` y con la insignia de marca/logo de la administradora.
     2. La entidad organizativa en `juntas`.
     3. Las credenciales únicas de acceso en `usuarios` con rol `JUNTA`.
   - El nuevo **Usuario Junta** puede iniciar sesión inmediatamente y acceder a `Portal Junta` y `Panel Junta` para administrar unidades, propietarios, alícuotas, recibos y cobranzas de su condominio.

### C. Claridad y Control en el Ecosistema Master
1. **Identificación y Mejora del Botón de Carga en Panel Master**:
   - En la bandeja de solicitudes recibidas del **Panel Master**, el botón antes etiquetado de forma ambigua como *"Carga"* se identifica explícitamente como **📋 Cargar Datos en Ficha de Revisión**.
   - Al pulsarlo sobre cualquier solicitud pendiente o aprobada, transfiere todos los datos del solicitante (Razón Social, RIF, Correo, Teléfono, Modalidad, enlace de documentos y logo) al formulario de inspección `#fichaSolicitudActiva`, realiza un desplazamiento suave (`smooth scroll`) hacia la ficha y aplica un destello visual de enfoque para que el Master pueda verificar, aprobar o habilitar el ecosistema con un clic.
2. **Terminal de Logs Única y Desplegable (Exclusiva Master)**:
   - En el **Portal Master** y en el **Panel Master**, la Terminal de Logs se presenta como un único bloque colapsable/desplegable (con botón **▼ Desplegar / ▲ Ocultar Terminal de Logs** y contador de eventos en vivo), eliminando cualquier instancia duplicada.
   - En todos los demás portales y paneles del sistema (Admin, Inversionista, Junta, Propietario), la terminal permanece oculta para los usuarios estándar y solo puede invocarse si existe una sesión verificada con rol `MASTER`.

---

## 3. Key Product Decisions & Trade-Offs

| Área de Decisión | Solución Seleccionada | Justificación y Beneficio Operativo |
| :--- | :--- | :--- |
| **Modelo PostgreSQL en Supabase** | **13 Tablas Relacionales con Columnas Tipadas + `payload JSONB`** | Permite consultas SQL indexadas por `id`, `usuario`, `rol`, `admin_id`, `junta_id` o `estado` en Supabase, mientras la columna `payload JSONB` garantiza compatibilidad total con cualquier campo dinámico del frontend sin errores de migración. |
| **Motor de Persistencia** | **Sincronización Dual en Tiempo Real (Supabase + JSON Local)** | Cada escritura actualiza en paralelo la base de datos local y Supabase (vía REST API y Storage Bucket `condolink-db-v208`). Si la conexión externa experimenta latencia, la interfaz responde en milisegundos y re-sincroniza en segundo plano. |
| **Navegación entre Paneles** | **Transición Limpia (`__clgNavegarLimpio`) y Variables Globales Idempotentes** | Sustituye el reemplazo destructivo del DOM (`document.write`) por navegación nativa con parámetros de sesión y normaliza declaraciones (`var BASE_URL`, `var safetyTimer`), erradicando el bloqueo de botones en los paneles del Administrador y Junta. |
| **Terminal de Auditoría Master** | **Componente Único Desplegable con Control RBAC** | Evita la saturación visual en el Panel Master mediante un contenedor colapsable único y protege la telemetría técnica ocultándola en los portales de clientes. |

---

## 4. Technical Architecture & Data Strategy

### A. Diagrama de Arquitectura y Sincronización Dual

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                   ECOSISTEMA MULTI-TENANT CONDOLINK V20.8                    │
│                                                                              │
│  ┌──────────────────────┐   Aprueba / Habilita   ┌────────────────────────┐  │
│  │    PORTAL / PANEL    │ ─────────────────────► │     PORTAL / PANEL     │  │
│  │        MASTER        │   (Datos + Logo URL)   │     ADMINISTRADOR      │  │
│  │  • Ficha de Revisión │                        │  • Ficha + Logo Activo │  │
│  │  • Logs Desplegables │                        │  • Alta de Propiedades │  │
│  └──────────┬───────────┘                        └───────────┬────────────┘  │
│             │                                                │               │
│             │                                    Crea Usuario Junta +        │
│             │                                    Ecosistema Condominio       │
│             │                                                ▼               │
│             │                                    ┌────────────────────────┐  │
│             │                                    │     PORTAL / PANEL     │  │
│             │                                    │  JUNTA DE CONDOMINIO   │  │
│             │                                    │  • Gestión de Unidades │  │
│             │                                    │  • Recibos y Finanzas  │  │
│             │                                    └───────────┬────────────┘  │
└─────────────┼────────────────────────────────────────────────┼───────────────┘
              │                                                │
              ▼                                                ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                 CAPA DE SERVICIOS Y API EXPRESS (/api/*)                     │
│  • Autenticación por Clave Única y Rol (MASTER, ADMIN, INVERSIONISTA, JUNTA) │
│  • Hidratación de Perfil Corporativo Admin (getPerfilAdmin + Logo + Prop.)   │
│  • Aprovisionamiento Atómico de Ecosistema Junta (Propiedad + Junta + User)  │
└──────────────────────────────────────┬───────────────────────────────────────┘
                                       │
                        Motor Dual en Tiempo Real (dbService)
                                       │
              ┌────────────────────────┴────────────────────────┐
              ▼                                                 ▼
┌───────────────────────────────────────────┐     ┌────────────────────────────┐
│     SUPABASE CLOUD (PostgreSQL + REST)    │     │  RESPALDO LOCAL (/db_json) │
│  • 13 Tablas Relacionales Tipadas         │◄───►│  • 13 Archivos .json       │
│  • Columna payload JSONB + Índices        │Sync │  • Lectura/Escritura Ágil  │
│  • Storage Bucket: condolink-db-v208      │     │  • Tolerancia Offline      │
└───────────────────────────────────────────┘     └────────────────────────────┘
```

### B. Esquema Relacional de las 13 Entidades en Supabase PostgreSQL
Cada una de las 13 tablas en Supabase cuenta con columnas relacionales tipadas para filtrado e indexación rápida, marcas de tiempo (`created_at`, `updated_at`) y una columna `payload JSONB NOT NULL DEFAULT '{}'::jsonb` que conserva el documento íntegro:

1. **`usuarios`**: `id` (PK), `usuario` (UNIQUE), `clave`, `rol` (`MASTER`, `ADMIN`, `INVERSIONISTA`, `JUNTA`, `PROPIETARIO`), `nombre`, `correo`, `telefono`, `rif`, `estado`, `modalidad`, `logo_url`, `admin_id`, `junta_id`, `propiedad_id`, `payload JSONB`.
2. **`solicitudes`**: `id` (PK), `tipo_cuenta` (`ADMIN`, `INVERSIONISTA`), `modalidad` (`PRUEBA`, `CONTRATACION`), `nombre`, `rif`, `correo`, `telefono`, `usuario_sugerido`, `clave_sugerida`, `rif_drive_url`, `logo_url`, `estado` (`PENDIENTE`, `APROBADA`, `RECHAZADA`), `dias_prueba`, `fecha_solicitud`, `fecha_aprobacion`, `payload JSONB`.
3. **`administradores`**: `id` (PK), `usuario`, `nombre`, `rif`, `correo`, `telefono`, `modalidad`, `estado`, `logo_url`, `rif_drive_url`, `fecha_vencimiento_prueba`, `payload JSONB`.
4. **`inversionistas`**: `id` (PK), `usuario`, `nombre`, `rif`, `correo`, `telefono`, `modalidad`, `estado`, `logo_url`, `rif_drive_url`, `payload JSONB`.
5. **`juntas`**: `id` (PK), `nombre`, `rif`, `correo`, `telefono`, `usuario`, `admin_id` (FK lógica a `administradores`), `propiedad_id`, `logo_admin_url`, `estado`, `payload JSONB`.
6. **`propiedades`**: `id` (PK), `nombre`, `rif`, `direccion`, `total_unidades`, `admin_id`, `inversionista_id`, `junta_id`, `usuario_junta`, `logo_url`, `estado`, `payload JSONB`.
7. **`unidades`**: `id` (PK), `propiedad_id`, `junta_id`, `codigo_unidad`, `propietario_nombre`, `propietario_correo`, `propietario_telefono`, `alicuota`, `saldo_pendiente`, `estado`, `payload JSONB`.
8. **`libro_diario`**: `id` (PK), `tenant_id`, `propiedad_id`, `fecha`, `concepto`, `tipo_movimiento` (`INGRESO`, `EGRESO`), `monto`, `moneda`, `referencia`, `payload JSONB`.
9. **`recibos`**: `id` (PK), `propiedad_id`, `junta_id`, `unidad_id`, `periodo`, `monto_total`, `saldo_abonado`, `estado` (`PENDIENTE`, `PAGADO`, `VENCIDO`), `payload JSONB`.
10. **`pagos`**: `id` (PK), `recibo_id`, `propiedad_id`, `unidad_id`, `monto`, `metodo_pago`, `referencia`, `fecha_pago`, `estado_verificacion`, `payload JSONB`.
11. **`comunicados`**: `id` (PK), `emisor_rol`, `tenant_id`, `propiedad_id`, `titulo`, `contenido`, `prioridad`, `fecha_publicacion`, `payload JSONB`.
12. **`mensajes`**: `id` (PK), `remitente_id`, `destinatario_id`, `asunto`, `cuerpo`, `leido`, `fecha_envio`, `payload JSONB`.
13. **`auditoria`**: `id` (PK), `accion`, `actor_usuario`, `actor_rol`, `modulo`, `detalle`, `nivel` (`INFO`, `WARN`, `SUCCESS`, `ERROR`), `fecha`, `payload JSONB`.

### C. Mapeo de Componentes Interactivos y Contratos de Estado

- **Sincronización y Prueba de Conexión Supabase**:
  - Endpoint de verificación `/api/supabase/test` y sincronización `/api/supabase/sync` que comprueban la conectividad con `https://yajkiybyejznqddnueoa.supabase.co`, sincronizan las 13 colecciones hacia las tablas PostgreSQL (vía `upsert` con resolución por `id`) y respaldan los snapshots JSON en el bucket `condolink-db-v208`.
- **Hidratación del Ecosistema Administrador (`/api/admin/perfil`)**:
  - Consolida en una sola respuesta los datos de `administradores`, `usuarios`, `solicitudes` aprobadas, `propiedades` y `juntas` asociadas al Administrador autenticado, asegurando que el **Logo Institucional**, RIF, modalidad y listado de condominios aparezcan siempre sincronizados en `Portal Admin`, `Panel Admin` e `Instalador Tenant Admin`.
- **Creación Atómica de Propiedad + Usuario Junta (`/api/admin/propiedades` y `/api/juntas/crear`)**:
  - Valida y registra la propiedad, crea el perfil de la Junta de Condominio y habilita el usuario en `usuarios` con su propia clave, permitiendo el inicio de sesión inmediato en el ecosistema Junta y el despliegue de sus paneles operativos.
- **Control de Ficha de Revisión y Terminal Desplegable en Master**:
  - El botón **📋 Cargar Datos en Ficha de Revisión** hidrata el formulario de revisión en `Panel Master` con desplazamiento guiado y resaltado visual, mientras que el conmutador `#btnToggleMasterLogs` controla la apertura y cierre de la única Terminal de Logs en `Portal Master` y `Panel Master`.
